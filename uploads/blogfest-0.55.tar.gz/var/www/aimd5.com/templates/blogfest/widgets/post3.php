<h1 class="strike noline grey"><span>Columns, Dropcaps and Pullquotes</span></h1>
				
				<div class="columns">
				
					<div class="su-column su-column-1-2"> <span class="dropcap_light">S</span>ed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien, et ornare felis. In eu mollis tellus. Sed et hendrerit ipsum. Nulla tincidunt lacus ut mi viverra fringilla. Nulla hendrerit suscipit massa et condimentum tincidunt vehicula. </div>
					<div class="su-column su-column-1-2 su-column-last"> <span class="dropcap_grey">C</span>urabitur dictum magna mi, iaculis bibendum tortor. Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa. Mauris mollis justo in ipsum aliquet molestie. Vestibulum non neque magna pulvinar tempor molestie.</div>
					<div class="su-spacer"></div>
					<div class="su-column su-column-1-3"><span class="dropcap_orange">D</span>olor sit amet, consectetur adipiscing elit. Aenean purus orci, iaculis sit amet rutrum in, dictum vel odio. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse potenti. Quisque convallis quam ut. </div>
					<div class="su-column su-column-1-3"><span class="dropcap_line">P</span>raesent nec dolor est. Mauris placerat est ut diam cursus ornare. Nullam ornare felis ut velit tincidunt rhoncus. Suspendisse potenti. Ut non ligula nec metus accumsan laoreet. Maecenas luctus dolor a mauris aliquet euismod.</div>
					<div class="su-column su-column-1-3 su-column-last"> <span class="dropcap_letter">C</span>ras tincidunt congue tortor, vitae pellentesque dolor dignissim in. Vivamus eu lobortis lectus. Etiam pulvinar tempor molestie. Quisque eleifend, augue ac gravida convallis, felis massa congue ipsum, sit amet imperdiet ipsum. </div>
					<div class="su-spacer"></div>				
				</div>