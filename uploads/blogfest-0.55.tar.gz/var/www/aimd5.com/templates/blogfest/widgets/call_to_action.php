	<div class="call_to_action">
				
	<h1>Lorem ipsum dolor sit amet consectetur </h1>
					
	<p><a href="#" class="button">Call to actionn</a></p>
					
	<p>Nunc congue, metus quis posuere tempor, nunc eros porta nibh, dignissim suscipit magna felis vitae velit. Quisque facilisis, felis placerat dignissim elementum, nisi massa malesuada nulla, in rutrum metus mauris at libero. Aliquam adipiscing tincidunt erat a fringilla. Fusce consequat ornare diam eget fermentum. Curabitur pellentesque scelerisque pulvinar. </p>
				
	</div>