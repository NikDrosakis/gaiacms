<?php $rposts=$cms->db->fa("SELECT post.* FROM post 			
			LEFT JOIN tax ON post.taxid=tax.id
			WHERE post.status=2 GROUP BY post.id 
			ORDER BY post.published DESC LIMIT 3 OFFSET 1
			");
?>


<div class="header_text">
			
		<div class="heading"><h1>Τελευταία Άρθρα</h1></div>
			<div class="stripe"></div>
				
	</div>

<?php for($i=0;$i<count($rposts);$i++){ ?>
	<div class="intro_block">
				
<div style="width:225px;height:150px;overflow: hidden;margin: 0 auto;">
	<a href="/<?=$rposts[$i]['uri']?>" title="Lorem ipsum">
		<img src="<?=$rposts[$i]['img']!='' ? UPLOADS.$rposts[$i]['img'] :'/templates/blogfest/images/225x150.gif'?>" style="width: 100%;height: auto;" alt="Lorem ipsum" />
	</a>
	</div>
					
		<h2><?=$rposts[$i]['title']?></h2>
					
<p style="text-align: justify;" ><?=$rposts[$i]['excerpt']?></p>
					
				</div>

<?php } ?>