<div class="portfolio_col2">
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
				
				<div class="col2">
					<a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="/templates/blogfest/images/305x150.gif" alt="Lorem ipsum" /></a>
					<p>The project title</p>
				</div>
			
				<!-- POSTS LISTINGS end here 
				================================================== -->
			
			</div>
				
			<div class="wp-pagenavi"> <!-- pagination start -->
			
				<span class="pages">Page 1 of 6</span>
				
				<span class="current">1</span>
				
				<a href="#" class="page larger">2</a>
				
				<a href="#" class="page larger">3</a>
				
				<a href="#" class="page larger">4</a>
				
				<a href="#" class="page larger">5</a>
				
				<span class="extend">...</span>
				
				<a href="#" class="nextpostslink">»</a>
				
				<a href="#" class="last">Last »</a>
				
			</div>	<!-- pagination end -->