    <div class="block_latest_left">
				
		<div class="header_line">
					
  	<h1>latest posts from posuere</h1>
					
		</div>
					
<div class="block_latest_content">
									
<p><a href="#" title="Lorem ipsum"><img src="/templates/blogfest/images/345x140.gif" alt="Lorem ipsum" /></a></p>
						
</div>
					
<div class="article_preview">
					
<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
<div class="article_preview_content">
						
<h3 class="dotted"><a href="#" title="Lorem ipsum dolor sim ament Crasis">Lorem ipsum dolor sim ament Crasis</a></h3>
<p>Posted on Jun 30, 2012 in <a href="#" title="Design magazine">Design Magazine</a> |  <a href="#" title="Comments">17 comments</a> </p>
							
</div>
					
</div>
				
<div class="article_preview">
					
<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
<div class="article_preview_content">
						
<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Dolor sit amet, consectetur</a></h3>
<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">5 comments</a> </p>
							
</div>
					
</div>
				
<div class="article_preview">
					
<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
<div class="article_preview_content">
						
<h3 class="dotted"><a href="#" title="Aliquam bibendum consequat vene">Aliquam bibendum consequat vene</a></h3>
	<p>Posted on Jun 20, 2012 in <a href="#" title="Inspirational">Inspirational</a> |  <a href="#" title="Comments">0 comments</a> </p>
							
</div>
					
					</div>
				
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
	<div class="article_preview_content">
						
	<h3 class="dotted"><a href="#" title="Sed et hendrerit ipsum felis arcu">Sed et hendrerit ipsum felis arcu</a></h3>
							<p>Posted on Jun 15, 2012 in <a href="#" title="Curagitur">Curagitur</a> |  <a href="#" title="Comments">4 comments</a> </p>
							
	</div>
					
		</div>
				
	</div>
				
	<div class="block_latest_right">
				
	<div class="header_line">
					
	<h1>latest posts from fermentum</h1>
					
		</div>
					
	<div class="block_latest_content">
									
	<p><a href="#" title="Lorem ipsum"><img src="/templates/blogfest/images/345x140.gif" alt="Lorem ipsum" /></a></p>
						
					</div>
					
	<div class="article_preview">
					
	<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
	<div class="article_preview_content">
						
	<h3 class="dotted"><a href="#" title="Nunc congue metus quis posuere tempor">Nunc congue metus quis posuere tempor</a></h3>
							<p>Posted on May 28, 2012 in <a href="#" title="Design magazine">Sci-Fi</a> |  <a href="#" title="Comments">2 comments</a> </p>
							
						</div>
					
					</div>
				
	<div class="article_preview">
					
	<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
	<div class="article_preview_content">
						
	<h3 class="dotted"><a href="#" title="Aenean vitae ultricies sapien adipiscing elit">Aenean vitae ultricies sapien adipiscing elit</a></h3>
							<p>Posted on May 21, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">8 comments</a> </p>
							
	</div>
					
	</div>
				
	<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Cras ut ligula quis tortor dapibus faucibus">Cras ut ligula quis tortor dapibus faucibus</a></h3>
							<p>Posted on May 10, 2012 in <a href="#" title="Inspirational">Inspirational</a> |  <a href="#" title="Comments">5 comments</a> </p>
							
						</div>
					
					</div>
				
	<div class="article_preview">
					
		<div class="article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
	<div class="article_preview_content">
						
	<h3 class="dotted"> <a href="#" title="In rutrum metus mauris at libero">In rutrum metus mauris at libero</a></h3>
	<p>Posted on May 7, 2012 in <a href="#" title="Curagitur">Curagitur</a> |  <a href="#" title="Comments">34 comments</a> </p>
							
	</div>
					
	</div>

</div>