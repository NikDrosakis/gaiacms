<div class="ad-728_bottom">
			
<div class="banner"><a href="#" title="advertisement"><img src="/templates/blogfest/images/728x90.gif" alt="Advertisement" /></a></div>
				<div class="promo"></div>
			
</div>