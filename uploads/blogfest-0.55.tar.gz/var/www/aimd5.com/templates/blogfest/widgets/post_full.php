<?php
$page=$this->GS['page'];
$post= $this->page()->post("WHERE uri='$page'"); ?>

<!---<p class="breadcrumbs"><a href="#" title="lorem">Home</a> » <a href="#" title="lorem">Graphic Design</a> » <a href="#" title="lorem">25 Adobe Photoshop actions for Photography Touch-Up and Enhancement</a></p>--->
				
<h1><?=$post['title']?></h1>
					
<div class="like">			
<div id="fb-root"></div>						
<script>(function(d, s, id) {
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) return;
 js = d.createElement(s); js.id = id; js.src="//connect.facebook.net/en_US/all.js#xfbml=1&appId=167757287776";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>

<div class="fb-like" data-href="https://www.facebook.com/venceremos.press" data-send="false" data-width="450" data-show-faces="false" data-action="like"></div>
					
</div>

<div class="meta">Δημοσιεύτηκε από <a href="#" title="lorem"><?=$this->user()->name($post['uid'])?></a> | <?=date('m ',$post['published']).$this->GS['greekMonths'][intval(date('m'))-1].date(' Y',$post['published'])?>
<!---	<a href="#" class="comments" title="lorem">10</a>--->
</div>
					
<div class="post_content">
					
<p>
	<span id="photo_<?=$post['img']?>" class="myPhoto" style="height:auto;">
	<a class="viewImage" href="<?=!empty($post['img']) ? UPLOADS.$post['img'] :'/templates/blogfest/images/500x375.gif'?>" title="<?=$post['img']?>">
	<img style="width: 100%;height: auto;margin: auto;" src="<?=!empty($post['img']) ? UPLOADS.$post['img'] :'/templates/blogfest/images/500x375.gif'?>" class="right" alt="lorem"/>
	</a>
	</span>
<!---<span class="dropcap_line">D</span>--->
	<?=$post['content']?>
</p>
						
<!--<div class="columns">-->
<!--<div class="su-column su-column-1-2 su-column-style-0"><span class="dropcap_line">S</span>ed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien, et ornare felis. In eu mollis tellus. Sed et hendrerit ipsum. Nulla tincidunt lacus ut mi viverra fringilla. Nulla hendrerit suscipit massa et condimentum tincidunt vehicula. </div>-->
<!--							<div class="su-column su-column-1-2 su-column-last su-column-style-0"><span class="dropcap_line">C</span>urabitur dictum magna mi, iaculis bibendum tortor. Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa. Mauris mollis justo in ipsum aliquet molestie. Vestibulum non neque magna pulvinar tempor molestie.</div>-->
<!--							<div class="su-spacer"></div>-->
<!--							<div class="su-column su-column-1-3 su-column-style-0"><h3 class="dotted">Dolor sit amet</h3>Consectetur adipiscing elit. Aenean purus orci, iaculis sit amet rutrum in, dictum vel odio. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse potenti. </div>-->
<!--							<div class="su-column su-column-1-3 su-column-style-0"><h3 class="dotted">Praesent nec dolor est</h3> Mauris placerat est ut diam cursus ornare. Nullam ornare felis ut velit tincidunt rhoncus. Suspendisse potenti. Ut non ligula nec metus accumsan laoreet. Maecenas luctus dolor a mauris aliquet euismod.</div>-->
<!--							<div class="su-column su-column-1-3 su-column-last su-column-style-0"><h3 class="dotted">Cras tincidunt congue tortor</h3> vitae pellentesque dolor dignissim in. Vivamus eu lobortis lectus. Etiam pulvinar tempor molestie. Quisque eleifend, augue ac gravida convallis, felis massa congue ipsum, sit amet imperdiet ipsum. </div>-->
<!--						</div>-->

	<div class="fb-comments" data-href="https://www.facebook.com/venceremos.press" data-numposts="3"></div>
	
</div>