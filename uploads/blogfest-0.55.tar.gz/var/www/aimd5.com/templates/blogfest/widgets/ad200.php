	<div class="ad-200">
				
	<div class="ad-200_left">
	<a href="#" title="" ><img src="/templates/blogfest/images/200x125.gif" alt="200x125 px spot" /></a>
	<a href="#" title="" ><img src="/templates/blogfest/images/200x125.gif" alt="200x125 px spot" /></a>
	</div>
				
	<div class="ad-200_right">
	<a href="#" title="" ><img src="/templates/blogfest/images/200x125.gif" alt="200x125 px spot" /></a>
	<a href="#" title="" ><img src="/templates/blogfest/images/200x125.gif" alt="200x125 px spot" /></a>
	</div>
			
	</div>