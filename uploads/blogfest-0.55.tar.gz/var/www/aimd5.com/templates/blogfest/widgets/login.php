<div class="login" id="register">
							
	<form action="#" method="get" accept-charset="utf-8">
					
	<fieldset>

	<p><label for="name">Username
		<input id="name" placeholder="Username"></label></p>
							
	<p><label  for="password">Password<input type="password" id="pass" placeholder="Password"></label></p>
							
	<!--- <p class="checkbox"><label for="remember">Remember me</label>
	<input type="checkbox" name="remember" id="remember"/>
	</p>	--->
	</fieldset>
	<input type="button" onclick="g.login()" class="button" value="Sign in">
	</form>
	</div>