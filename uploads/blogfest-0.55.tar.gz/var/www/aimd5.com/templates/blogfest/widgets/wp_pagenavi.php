<div class="wp-pagenavi"> 
			
<span class="pages">Page 1 of 6</span>
				
<span class="current">1</span>
				
<a href="#" class="page larger">2</a>
				
<a href="#" class="page larger">3</a>
				
<a href="#" class="page larger">4</a>
				
<a href="#" class="page larger">5</a>
				
<span class="extend">...</span>
				
<a href="#" class="nextpostslink">»</a>
				
<a href="#" class="last">Last »</a>
				
</div>	