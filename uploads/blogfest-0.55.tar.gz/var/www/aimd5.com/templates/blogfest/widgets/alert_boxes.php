<h1 class="strike noline grey"><span>Alert Boxes</span></h1>
				
				<div class="su-column su-column-1-2 su-column-style-0"> 
				
					<p class="error-msg"><strong>Error</strong> - Your message! </p>
					<p class="warning"><strong>Warning</strong> - Your message!</p>
				
				</div>
				
				<div class="su-column su-column-1-2 su-column-last su-column-style-0"> 
				
					<p class="info"><strong>Info</strong> - Your message! </p>
					<p class="success"><strong>Success</strong> - Your message! </p>
					
				</div>
				
				<div class="su-spacer"></div>	