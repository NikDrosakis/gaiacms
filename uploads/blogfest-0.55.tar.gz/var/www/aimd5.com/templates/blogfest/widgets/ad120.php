<div class="widget_120_container">
	
<div class="blogroll">
				
		<h1>Blogroll</h1>
					
<ul>
<li><a href="#" title="">Documentation</a></li>
<li><a href="#" title="">Plugins</a></li>
<li><a href="#" title="">Suggest Ideas</a></li>
<li><a href="#" title="">Support Forum</a></li>
<li><a href="#" title="">Themes</a></li>
<li><a href="#" title="">WordPress Blog</a></li>
<li><a href="#" title="">WordPress Planet</a></li>
<li><a href="#" title="">MagTruetitude</a></li>
<li><a href="#" title="">Redminton</a></li>
<li><a href="#" title="">Buy this theme</a></li>
					</ul>
				
</div>
<div class="ad_120"><a href="#" title="" ><img src="/templates/blogfest/images/120x240.gif" alt="Lorem ipsum" /></a></div>
<div class="ad_120"><a href="#" title="" ><img src="/templates/blogfest/images/120x240.gif" alt="Lorem ipsum" /></a></div>
			
</div>