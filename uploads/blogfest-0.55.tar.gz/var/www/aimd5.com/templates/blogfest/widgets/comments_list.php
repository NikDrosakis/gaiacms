<div id="comments-list">

<h2>2 Responses</h2>
						
<ul>
						
<li class="comment">
							
<div class="comment-body">						
									<div class="comment-author">
									
										<img alt="" src="/templates/blogfest/images/avatar.png" class="avatar"/>
										<h3 class="name">Lara Flaber</h3>
										<p class="comment-meta">February 3, 2012 at 11:13 pm</p>								
									</div>									
									<p>Dolor sit amet, consectetur adipiscing elit. Aenean purus orci, iaculis sit amet rutrum in, dictum vel odio. Vestibulum ante ipsum primis in faucibus orci luctus 
									et ultrices posuere cubilia Curae; Suspendisse potenti. Quisque convallis quam ut lacus malesuada vitae tristique odio faucibus. 
									</p>
									
								</div>
								
								<ul class="children">
								
									<li class="comment odd">
									
										<div class="comment-body">
										
											<div class="comment-author">
											
												<img alt="" src="/templates/blogfest/images/avatar.png" class="avatar"/>
												<h3 class="name">Admin</h3>
												<p class="comment-meta">May 8, 2012 at 11:27 pm</p>
											
											</div>
											
											<p>Donec elit risus, consequat quis mattis ac, auctor nec massa. Aliquam eu tortor neque, quis vulputate nisi. </p>

										</div>
									
									</li>
									
								</ul>
								
							</li>
						
						</ul>

					</div>	

					<!-- COMMENT FORM start here 
					================================================== -->
			
					<div id="respond">
					
						<h2>Leave a Reply</h2>

						<form action="#" method="post" id="commentform">
						
							<div class="form_row">
							
								<div class="form_item">
								
									<label for="author">Name</label>
									<input type="text" name="author" id="author" value="" size="22" tabindex="1" />
									
								</div>
								
								<div class="form_item">
								
									<label for="email">E-mail</label>
									<input type="text" name="email" id="email" value="" size="22" tabindex="2" />
									
								</div>
								
								<div class="form_item">
								
									<label for="url">Website</label>
									<input type="text" name="url" id="url" value="" size="22" tabindex="3" />
									
								</div>
							
							</div>
							
							<div class="form_row">
							
								<div class="form_item_comment">
								
									<label for="comment">Comment</label>
									 <textarea name="comment" id="comment" cols="58" rows="10" tabindex="4" > </textarea>

								
								</div>
							
							</div >
							
							<div class="form_row">
							
								<div class="submit_comment">
								
									<input name="submit" type="submit" class="button" tabindex="5" value="Submit Comment"/>
								
								</div>
							
							</div>
					
						</form>
					
					</div>