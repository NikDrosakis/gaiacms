<div class="social_counter_twitter">				
<a href="http://twitter.com/designsmix" title="Follow us on Twitter">Twitter</a>
<span id="twitter"></span>
</div>
			
<div class="social_counter_facebook">				
<a href="#" title="Like us on Facebook">Facebook</a>
<span id="facebook"></span>
</div>
			
<div class="social_counter_delicious">
<a href="#" title="bookmark us">Delicious</a>
<span id="delicious"></span>
</div>