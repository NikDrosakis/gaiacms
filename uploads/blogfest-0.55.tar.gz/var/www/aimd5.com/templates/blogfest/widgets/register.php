	<div class="register">
							
	<form action="#" method="get" accept-charset="utf-8">
					
	<fieldset><p><label for="reg_username">Username</label><br />
	<input type="text" name="reg_username" id="reg_username"></p>
							
	<p><label for="email">Email</label><br />
<input type="text" name="reg_email" value="" id="email">
</p>
							
<p><label for="reg_password">Password</label><br />
<input type="password" name="reg_password" value="" id="reg_password"></p>
							
	</fieldset>
					
	<input type="submit" class="button" value="Register">
						
	</form>
							
	</div>