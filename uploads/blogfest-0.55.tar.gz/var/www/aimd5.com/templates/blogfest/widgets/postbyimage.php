<div class="header_text">
				
					<div class="heading"><h1>Post by image</h1></div>
					<div class="stripe"></div>
				
				</div>
				
				<div class="post_by_image">
				
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
					<div class="post_by_image_th"><a href="/templates/blogfest/images/800x600.gif" data-rel="prettyPhoto[gallery]" title="Lorem ipsum"><img src="/templates/blogfest/images/55x55.gif" alt="Lorem ipsum" /></a></div>
				
				</div>