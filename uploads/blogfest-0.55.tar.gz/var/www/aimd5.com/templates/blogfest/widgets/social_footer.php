        <div class="footer_social">

            <ul>
                <li><a href="#" title="" ><img src="/templates/blogfest/images/icon_rss.png" alt="RSS" /></a></li>
                <li><a href="#" title="" ><img src="/templates/blogfest/images/icon_twitter.png" alt="Twitter" /></a></li>
                <li><a href="#" title="" ><img src="/templates/blogfest/images/icon_facebook.png" alt="Facebook" /></a></li>
                <li><a href="#" title="" ><img src="/templates/blogfest/images/icon_deviantart.png" alt="DevianART" /></a></li>
                <li><a href="#" title="" ><img src="/templates/blogfest/images/icon_vimeo.png" alt="Vimeo" /></a></li>
            </ul>

        </div>