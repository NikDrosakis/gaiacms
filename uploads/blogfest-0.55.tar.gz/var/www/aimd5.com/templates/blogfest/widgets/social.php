<div class="social_icons">
				
	<ul><li><a href="#" title="" ><img src="/templates/blogfest/images/icon_twitter_2.png" alt="Twitter" /></a></li>
	<li><a href="#" title="" ><img src="/templates/blogfest/images/icon_facebook_2.png" alt="Facebook" /></a></li>
	<li><a href="#" title="" ><img src="/templates/blogfest/images/icon_rss.png" alt="RSS" /></a></li>
	</ul>
				
</div>