<?php
$sel=$cms->db->fetchList("filename","obj","WHERE status=2");
?>
<div class="flexslider">
			
<ul class="slides">
<?php foreach($sel as $s){ ?>
<li style="width:710px;height:360px;overflow:hidden">
    <img src="<?=UPLOADS.$s?>" style="width: 800px; margin:auto;" alt="slide" /></li>
<?php } ?>
</ul>

</div>	