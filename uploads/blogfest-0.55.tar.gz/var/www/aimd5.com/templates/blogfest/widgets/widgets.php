<?php $post1=$this->page()->post(); ?>

<div class="post_container">
<div class="post">
		
<p>
<!--    <span class="dropcap_line">D</span>-->
    <?=urldecode($post1['excerpt']);?>
</p>

<h1 class="strike noline grey"><span><?=html_entity_decode($post1['title']);?></span></h1>
<!--<div class="columns">-->
<!--<div class="su-column su-column-1-2">Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien, et ornare felis. In eu mollis tellus. Sed et hendrerit ipsum. Nulla tincidunt lacus ut mi viverra fringilla. Nulla hendrerit suscipit massa et condimentum tincidunt vehicula. </div>-->
<!--<div class="su-column su-column-1-2 su-column-last">Curabitur dictum magna mi, iaculis bibendum tortor. Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa. Mauris mollis justo in ipsum aliquet molestie. Vestibulum non neque magna pulvinar tempor molestie.</div>-->
<!--</div>-->
    <span style="width:500px;height:auto;">
	<img style="width: 100%;height: auto;margin: auto;" src="<?=!empty($img) ? UPLOADS.$img :'/templates/blogfest/images/500x375.gif'?>" class="right" alt="lorem"/>
	</span>

    <a href="/<?=$post1['uri']?>" class="read_more" style="padding: 10px 24px;margin: 20px 10px 16px 21px;">Περισσότερα</a>
<div class="spacer"></div>
			
</div>
				
</div>