<div class="flexslider portfolio"> 
			
			  <ul class="slides"> 
				<li> 
				  <img src="/templates/blogfest/images/slide_3.gif" alt="slide" /> 
				</li> 
				<li> 
				  <img src="/templates/blogfest/images/slide_3.gif" alt="slide" /> 
				</li> 
				<li> 
				  <img src="/templates/blogfest/images/slide_1.gif" alt="slide" /> 
				</li> 
				<li> 
				  <img src="/templates/blogfest/images/slide_4.gif" alt="slide" /> 
				</li> 

			  </ul> 
			  
			</div> 	