<div class="post">
				
<h1>This is heading 1</h1>
					
<div class="columns">
				
<div class="su-column su-column-1-2">Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien, et ornare felis. In eu mollis tellus. Sed et hendrerit ipsum. Nulla tincidunt lacus ut mi viverra fringilla. Nulla hendrerit suscipit massa et condimentum tincidunt vehicula. </div>

<div class="su-column su-column-1-2 su-column-last">Curabitur dictum magna mi, iaculis bibendum tortor. Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa. Mauris mollis justo in ipsum aliquet molestie. Vestibulum non neque magna pulvinar tempor molestie.</div>

<div class="su-spacer"></div>
					
</div>

<h1 class="strike noline grey"><span>This is heading 1 with "strike" class</span></h1>
					
<div class="columns">
				
<div class="su-column su-column-1-1 su-column-last">Curabitur dictum magna mi, iaculis bibendum tortor. Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa. Mauris mollis justo in ipsum aliquet molestie. Vestibulum non neque magna pulvinar tempor molestie.</div>
					
</div>
					
<div class="columns">	
<div class="su-column su-column-1-3"><h2>This is heading 2</h2> Nunc congue, metus quis posuere tempor, nunc eros porta nibh, dignissim suscipit magna felis vitae velit. Quisque facilisis, felis placerat dignissim elementum, nisi massa malesuada nulla, in rutrum metus mauris at libero. Aliquam adipiscing tincidunt erat a fringilla. </div>

<div class="su-column su-column-1-3"><h3>This is heading 3</h3>Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien, et ornare felis. In eu mollis tellus. Sed et hendrerit ipsum. Nulla tincidunt lacus ut mi viverra fringilla. Nulla hendrerit suscipit massa et condimentum tincidunt vehicula. </div>

<div class="su-column su-column-1-3	 su-column-last"><h4>This is heading 4</h4>Curabitur dictum magna mi, iaculis bibendum tortor. Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa. Mauris mollis justo in ipsum aliquet molestie. Vestibulum non neque magna pulvinar tempor molestie.</div>
<div class="su-spacer"></div>
					
</div>
					
<div class="columns">
				
<div class="su-column su-column-1-1 su-column-last"><h5>This is heading 5</h5>Curabitur dictum magna mi, iaculis bibendum tortor. Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa. Mauris mollis justo in ipsum aliquet molestie. Vestibulum non neque magna pulvinar tempor molestie.</div>
					
</div>
				
<div class="columns">
				
<div class="su-column su-column-1-1"><h3 class="dotted">Dotted heading</h3>Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien, et ornare felis. In eu mollis tellus. Sed et hendrerit ipsum. Nulla tincidunt lacus ut mi viverra fringilla. Nulla hendrerit suscipit massa et condimentum tincidunt vehicula. 
Praesent nec dolor est. Mauris placerat est ut diam cursus ornare. Nullam ornare felis ut velit tincidunt rhoncus. Suspendisse potenti. Ut non ligula nec metus accumsan laoreet. Maecenas luctus dolor a mauris aliquet euismod.</div>
<div class="su-spacer"></div>
					
</div>
				
</div>