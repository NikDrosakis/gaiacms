<h1 class="strike noline grey"><span>Right and left pullquotes</span></h1>
				
				<div class="su-pullquote su-pullquote-align-left">Aliquam erat volutpat</div>
				<p>
					<span> Dolor sit amet, consectetur adipiscing elit. Aenean purus orci, iaculis sit amet rutrum in, dictum vel odio. 
					Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse potenti. 
					Quisque convallis quam ut lacus malesuada vitae tristique odio faucibus. Donec in erat ligula. Aliquam erat volutpat.</span>
				</p>
								
				<div class="su-pullquote su-pullquote-align-right">Quisque fringilla risus nec libero consectetur</div>
				<p>
					<span> Dolor sit amet, consectetur adipiscing elit. Aenean purus orci, iaculis sit amet rutrum in, dictum vel odio. 
					Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Suspendisse potenti. 
					Quisque convallis quam ut lacus malesuada vitae tristique odio faucibus. Donec in erat ligula. Aliquam erat volutpat. Etiam pulvinar tempor molestie. 
					Quisque eleifend, augue ac gravida convallis, felis massa congue ipsum, sit amet imperdiet massa ipsum et felis. Integer non venenatis ligula. 
					Pellentesque ac felis bibendum enim tincidunt vehicula. </span>
				</p>
					
				<div class="spacer"></div>