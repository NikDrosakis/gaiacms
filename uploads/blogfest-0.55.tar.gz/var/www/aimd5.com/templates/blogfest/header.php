    <div id="main">

        <header><!-- ====HEADER start here===== -->

            <div class="header">

                <div class="logo center"><a href="/"><img src="/templates/blogfest/images/logo_big.png" alt="logo" width="750"/></a></div>

            </div>

           <?php $this->page()->module('menutop'); ?>

        </header><!-- ====HEADER end here===== -->
<?php // $this->page()->module('ad728'); ?>
