<link rel="stylesheet" href="/templates/blogfest/css/base.css" />
<link rel="stylesheet" href="/templates/blogfest/css/layout.css" />
<link rel="stylesheet" href="/templates/blogfest/css/skeleton.css" />
<link rel="stylesheet" href="/templates/blogfest/css/flexslider.css" />
<link rel="stylesheet" href="/templates/blogfest/css/prettyPhoto.css" />

<!--[if  IE]>
<link rel="stylesheet" href="/templates/blogfest/css/ie.css">
<![endif]-->

<!--[if lt IE 9]>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

    <div id="main">

        <header><!-- ====HEADER start here===== -->

            <div class="header">

                <div class="logo center"><a href="/"><img src="/templates/blogfest/images/logo_big.png" alt="logo" width="750"/></a></div>

            </div>

			<span id="menutop" class="wid"></span>
           
        </header><!-- ====HEADER end here===== -->
<?php // $this->page()->module('ad728'); ?>

<span id="flexslider" class="wid"></span>

<span id="post" class="wid"></span>
		
<div class="content">

<span id="latest_post" class="wid"></span>		
				
</div>			
		
</div><!-- MAIN CONTENT end here ====== -->
		
<!--====== Sidebar====== -->

	
<div id="sidebar">


<!--<textarea id="mymessage"></textarea>-->
<!--    <button onclick="post_message($('#mymessage').val())">Post to facebook</button>-->
<!--    <div id="status">    </div>-->
<!--<div class="fb-login-button" data-max-rows="1" data-size="large" data-show-faces="false" data-auto-logout-link="false"></div>-->

<span id="social_login" class="wid"></span>


<span id="login" class="wid"></span>

<span id="register" class="wid"></span>



<div class="social_and_search">
<span id="social" class="wid"></span>

<span id="subscribe" class="wid"></span>
			
</div>

<span id="article_widget" class="wid"></span>				

<span id="fb_page_plugin" class="wid"></span>
		
<span id="tab_widget" class="wid"></span>

			
<?php //$this->page()->module('twitter_widget'); ?>


<div style="margin:15px">
<a class="twitter-timeline" href="https://twitter.com/venceremospress">Tweets by venceremospress</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
</div>

<div class="copyright">
 <?=$this->is('copyright')?>
 v.<?=$this->is('this_version')?>
</div>


</div> <!-- sidebar end -->

<a href="#" class="scrollup">Scroll</a>
<!-- ====Footer===== -->

<footer>
 <!--   <div id="footer">-->

<?php // $this->page()->module('menu_footer'); ?>

<?php // $this->page()->module('social_footer'); ?>

 <!--       </div> -->

</footer>

</div>
</div>

<!-- ====Scripts==== -->

<script src="/templates/blogfest/js/make_dropdown.js"></script>
<script src="/templates/blogfest/js/jquery.infieldlabel.min.js"></script>
<script defer src="/templates/blogfest/js/functions.js"></script>
<script defer src="/templates/blogfest/js/jquery.flexslider.js"></script>
<!--<script src="/templates/blogfest/twitter/jquery.tweet.js"></script>--->
<script src="/templates/blogfest/js/jquery.prettyPhoto.js"></script>

<script type="text/javascript">

    $(window).load(function() {

        $('.flexslider').flexslider({
            animationLoop: true,
            controlNav: false,
            animation: "slide",
        });

        // lightbox
        $("a[data-rel^='prettyPhoto']").prettyPhoto();

    });

</script>

</body>
</html>