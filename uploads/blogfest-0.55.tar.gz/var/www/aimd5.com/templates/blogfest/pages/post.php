<!-- POSTS LISTINGS start here
			================================================== -->
<div class="post_container">

<div class="post">

<span id="post_full" class="mid"></span>				
							
<?php // $this->page()->module('comments_list'); ?>

<?php // $this->page()->module('comment_form'); ?>

</div>

</div>
			
<span id="tags" class="mid"></span>

<?php // $this->page()->module('ad728'); ?>

<div class="content">
	<?php // $this->page()->module('block_latest_left'); ?>
</div>

</div>

<div id="sidebar">

	<div class="social_and_search">
<span id="social" class="mid"></span>
<span id="subscribe" class="mid"></span>
		<?php // $this->page()->module('search'); ?>

	</div>

<?php // $this->page()->module('ad200'); ?>
<span id="article_widget" class="mid"></span>

<span id="tab_widget" class="mid"></span>


<?php // $this->page()->module('ad120'); ?>
<span id="twitter_widget" class="mid"></span>


<?php // $this->page()->module('ad336'); ?>
