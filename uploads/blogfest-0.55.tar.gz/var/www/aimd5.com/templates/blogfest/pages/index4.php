<!doctype html>
<head>

  <meta charset="utf-8">
  
	<!-- Website title
        ================================================== -->
		<title>Home 4</title>
	  
		<meta name="description" content="">
	<!-- Mobile Specific Metas
	    ================================================== -->
		
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		
	<!-- Stylesheets
        ================================================== -->
		
		<link rel="stylesheet" href="css/base.css" />
		<link rel="stylesheet" href="css/layout.css" />
		<link rel="stylesheet" href="css/skeleton.css" />
		<link rel="stylesheet" href="css/flexslider.css" />
		<link rel="stylesheet" href="css/prettyPhoto.css" />
		
		<!--[if  IE]>
		<link rel="stylesheet" href="css/ie.css">
		<![endif]-->
		
		<!--[if lt IE 9]>
			<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
</head>

<body>
  
	<div id="wrapper">
  
		<div id="main">
		
			<header><!-- HEADER start here 
			================================================== -->
			
			<div class="header">
			
				<div class="logo"><a href="index.html"><img src="images/logo.jpg" alt="logo" /><span>Blogfest Concept</span></a></div>
				
				<div class="logo-tag">
					<ul>
					
						<li><span class="orange">Art</span> related</li>
						<li><span class="orange">Graphic</span> Design</li>
						<li><span class="orange">Tutorials</span> and Freebies</li>
						<li><span class="orange">Community</span> submit news</li>
					
					</ul>
				</div>
			
			</div>
			
			<div id="dd" class="menu wrapper-dropdown"><span class="responsive_label">Select a page</span>
				
				<ul id="menu-mobile" class="dropdown">
					<li><a href="index.html" title="home page">Home</a>
						<ul>
							<li><a href="index2.html" title="home 2">Home 2</a></li>
							<li><a href="index3.html" title="home 3">Home 3</a></li>
							<li><a href="index4.html" title="home 4">Home 4</a></li>
						</ul>
					</li>
					<li class="register_mobile"><a href="#register" title="home page">Login / Register</a></li>
					<li><a href="faq.html" title="Features">Features</a>
						<ul>
							<li><a href="faq.html" title="home">FAQ</a></li>
							<li><a href="404.html" title="404 error">404 Error</a></li>
							<li><a href="advertising.html" title="Advertising">Advertising</a></li>
						</ul>
					</li>
					<li><a href="portfolio.html" title="portfolio">Portfolio</a>
						<ul>
							<li><a href="portfolio.html" title="portfolio">With slider</a>
							<li><a href="portfolio-2col.html" title="portfolio 2">2 Columns</a>
							<li><a href="portfolio-3col.html" title="portfolio 3">3 Columns</a>
						</ul>
					</li>
					<li><a href="elements.html" title="styles">Styles</a>
						<ul>
							<li><a href="elements.html" title="elements">Elements</a></li>
							<li><a href="headings.html" title="headings">Headings</a>
							<li><a href="tables.html" title="pricing boxes">Pricing tables</a></li>
						</ul>
					</li>
					<li><a href="post.html" title="single blog post">Bloging</a>
						<ul>
							<li><a href="category.html" title="category template">Category</a></li>
							<li><a href="post.html" title="single blog post">Single post</a></li>
							<li><a href="results.html" title="search results">Search results</a>
						</ul>
					</li>
					<li><a href="contact.php" title="Contact">Contact</a></li>
				</ul>
				
			</div>
			
			</header><!-- HEADER end here
			================================================== -->
			
			<div class="ad-728">
			
				<div class="banner"><a href="#" title="advertisement"><img src="images/728x90.gif" alt="Advertisement" /></a></div>
				<div class="promo"></div>
			
			</div>
			
			<!-- SLIDER start here 
			================================================== -->
		
			<div class="flexslider"> 
			
			  <ul class="slides"> 
				<li> 
				  <img src="images/slide_3.gif" alt="slide" /> 
				</li> 
				<li> 
				  <img src="images/slide_2.gif" alt="slide" /> 
				</li> 
				<li> 
				  <img src="images/slide_1.gif" alt="slide" /> 
				</li> 
				<li> 
				  <img src="images/slide_4.gif" alt="slide" /> 
				</li> 

			  </ul> 
			  
			</div> 	
			
			<!-- SLIDER end here 
			================================================== -->

			<div class="tier">
		
				<div class="tier_block">
				
					<h2>Faucibus</h2>
					<p class="tier_icon"><a href="#" title="Article"><img src="images/article_icon.jpg" alt="Article" /></a></p>
					<p class="tier_excerpt">Dolor sit amet, consectetur adipiscing elit. Aenea purus orci, iaculis sit amet rutrum in, dictum vel odio. </p>
				
				</div>
			
				<div class="tier_block">
				
					<h2>consectetur </h2>
					<p class="tier_icon"><a href="#" title="Options"><img src="images/options_icon.jpg" alt="Theme Options" /></a></p>
					<p class="tier_excerpt">Dolor sit amet, consectetur adipiscing elit. Aenea purus orci, iaculis sit amet rutrum in, dictum vel odio. </p>
				
				</div>
			
				<div class="tier_block">
				
					<h2>Egetiper </h2>
					<p class="tier_icon"><a href="#" title="Advertising"><img src="images/advertising_icon.jpg" alt="Advertising module" /></a></p>
					<p class="tier_excerpt">Dolor sit amet, consectetur adipiscing elit. Aenea purus orci, iaculis sit amet rutrum in, dictum vel odio. </p>
				
				</div>
				
			</div>
			
			<!-- MAIN CONTENT start here 
			================================================== -->
		
			<div class="content">
		
				
				<div class="block_latest_left">
				
					<div class="header_line">
					
						<h1>latest posts from posuere</h1>
					
					</div>
					
					<div class="block_latest_content">
									
						<p><a href="#" title="Lorem ipsum"><img src="images/345x140.gif" alt="Lorem ipsum" /></a></p>
						
					</div>
					
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Lorem ipsum dolor sim ament Crasis">Lorem ipsum dolor sim ament Crasis</a></h3>
							<p>Posted on Jun 30, 2012 in <a href="#" title="Design magazine">Design Magazine</a> |  <a href="#" title="Comments">17 comments</a> </p>
							
						</div>
					
					</div>
				
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Dolor sit amet, consectetur</a></h3>
							<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">5 comments</a> </p>
							
						</div>
					
					</div>
				
				
				</div>
				
				<div class="block_latest_right">
				
					<div class="header_line">
					
						<h1>latest posts from fermentum</h1>
					
					</div>
					
					<div class="block_latest_content">
									
						<p><a href="#" title="Lorem ipsum"><img src="images/345x140.gif" alt="Lorem ipsum" /></a></p>
						
					</div>
					
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Nunc congue metus quis posuere tempor">Nunc congue metus quis posuere tempor</a></h3>
							<p>Posted on May 28, 2012 in <a href="#" title="Design magazine">Sci-Fi</a> |  <a href="#" title="Comments">2 comments</a> </p>
							
						</div>
					
					</div>
				
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Aenean vitae ultricies sapien adipiscing elit">Aenean vitae ultricies sapien adipiscing elit</a></h3>
							<p>Posted on May 21, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">8 comments</a> </p>
							
						</div>
					
					</div>
				
				</div>
				
				<div class="su-spacer"></div>	
				
				<div class="call_to_action">
				
					<h1>Lorem ipsum dolor sit amet consectetur </h1>
					
					<p><a href="#" class="button">Call to actionn</a></p>
					
					<p>Nunc congue, metus quis posuere tempor, nunc eros porta nibh, dignissim suscipit magna felis vitae velit. Quisque facilisis, felis placerat dignissim elementum, 
					nisi massa malesuada nulla, in rutrum metus mauris at libero. Aliquam adipiscing tincidunt erat a fringilla. Fusce consequat ornare diam eget fermentum. 
					Curabitur pellentesque scelerisque pulvinar. </p>
				
				</div>
				
				<div class="content_col2">
				
					<div class="col2">
					
						<a href="images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="images/305x150.gif" alt="Lorem ipsum" /></a>
						
						<h2 class="strike"><em>faucibus turpis dolor egetiper</em></h2>
						
						<p>Sed sed arcu sed sem consequat ultri-cies vitae sit amet ipsum. Curabitur quis diam sapien, et ornare felis. In eu mollis tellus. 
						Sed et hendrerit ipsum. Nulla tincidunt lacus ut mi viverra fringilla. Nulla hendrerit suscipit massa et condimentum... </p>

					</div>
					
					<div class="col2">
					
						<a href="images/800x600.gif" data-rel="prettyPhoto" title="Lorem ipsum"><img src="images/305x150.gif" alt="Lorem ipsum" /></a>
						
						<h2 class="strike"><em>Quisque facilisis dignissim</em></h2>
						
						<p>Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue. Nulla ultricies massa viverra tortor rutrum et condimentum leo consectetur. 
						Sed placerat augue eu eros ultrices sodales. Nullam aliquet luctus...</p>
						
					</div>
				
				</div>
				
			</div>
			
			<!-- MAIN CONTENT end here 
			================================================== -->
		
		</div>
		
		<!-- Sidebar
			================================================== -->
		
		<div id="sidebar">
		
			<div class="social_counter">
			
				<div class="social_counter_twitter">
				
					<a href="#" title="Follow us on Twitter">Twitter</a>
					<span id="twitter"></span>
				
				</div>
			
				<div class="social_counter_facebook">
				
					<a href="#" title="Like us on Facebook">Facebook</a>
					<span id="facebook"></span>
				</div>
			
				<div class="social_counter_delicious">
				
					<a href="#" title="bookmark us">Delicious</a>
					<span id="delicious"></span>
				</div>
			
				<div class="social_and_subscribe">
				
					<div class="social_icons">
					
						<ul>
							<li><a href="#" title="" ><img src="images/icon_twitter_2.png" alt="Twitter" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_facebook_2.png" alt="Facebook" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_behance.png" alt="Behance" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_dribbble.png" alt="Dribbble" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_flickr.png" alt="Flickr" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_rss_2.png" alt="RSS" /></a></li>
						</ul>
					
					</div>
					
					<div class="subscribe">
					
						<form action="#" method="get" accept-charset="utf-8">
							<fieldset>
							<p><label for="s">subscribe with your email</label>
							<input type="text" class="subscribebox" name="s" value="" id="s"/>
							<input type="submit" class="subscribebox_submit" value="" /></p>
							</fieldset>
						</form>
					
					</div>
				
				</div>
			
			</div>
				
			<div class="ad-200">
				
				<div class="ad-200_left">
					<a href="#" title="" ><img src="images/200x125.gif" alt="200x125 px spot" /></a>
					<a href="#" title="" ><img src="images/200x125.gif" alt="200x125 px spot" /></a>
				</div>
				
				<div class="ad-200_right">
					<a href="#" title="" ><img src="images/200x125.gif" alt="200x125 px spot" /></a>
					<a href="#" title="" ><img src="images/200x125.gif" alt="200x125 px spot" /></a>
				</div>
			
			</div>
			
			<div class="article_widget">
			
				<div class="article_widget_preview">
				
					<a href="#" title="" ><img src="images/200x125.gif" alt="lorem ipsum" /></a>
					
					<h1><a href="#" title="faucibus turpis eget i perdiet esci">faucibus turpis eget i perdiet esci</a></h1>
					
					<p>
						Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien...
					</p>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Aliquam bibendum consequat vene">Aliquam bibendum ed consequat vene</a></h3>
						<p class="meta"><a href="#">June 12, 2012</a></p>
						<p class="comments"><a href="#">38</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Sed et hendrerit aenon dolor">Sed et hendrerit ut aenon dolor...</a></h3>
						<p class="meta"><a href="#">June 08, 2012</a></p>
						<p class="comments"><a href="#">177</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Curabitur dictum magna mi">Curabitur eros et dictum magna mi</a></h3>
						<p class="meta"><a href="#">June 05, 2012</a></p>
						<p class="comments"><a href="#">15</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Pellentesque vel sem id libero mollis">Pellentesque vel sem id libero mollis</a></h3>
						<p class="meta"><a href="#">June 01, 2012</a></p>
						<p class="comments"><a href="#">103</a></p>
						
					</div>
				
				</div>
			
			</div>
			
			<div class="tab_widget">
			
				<ul class="tabs"> 
					<li class="active" ><em title="tab1">Popular  posts</em></li>
					<li><em title="tab2">recent  posts</em></li>
					<li><em title="tab3">Comments</em></li>
				</ul>	

				<div class="tab_container"> 

					 <div id="tab1" class="tab_content"> 
				 
						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Curabitur dictum magna mi iaculis bibendum</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">5 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Donec eros augue, tristique in feugiat ut pellentes</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Curagitur</a> |  <a href="#" title="Comments">0 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Nullam sit amet ipsum non diam eleifend rhoncus</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Inspirational</a> |  <a href="#" title="Comments">21 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Quisque fringilla risus nec libero consectetur</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">32 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Quisque fringilla risus nec libero consectetur</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">32 comments</a> </p>
								
							</div>
						
						</div>

					 </div><!-- #tab1 -->
					 
					 <div id="tab2" class="tab_content"> 

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Mauris mollis justo in ipsum aliquet molestie</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">22 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">In bibendum, nibh a gravida porta sapien neque</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Curagitur</a> |  <a href="#" title="Comments">54 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Curabitur vestibulum lectus sed augue sollicit</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Inspirational</a> |  <a href="#" title="Comments">2 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Vivamus adipiscing sollicitudin lectus</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">125 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Aenean felis arcu, suscipit vitae pulvinar</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">10 comments</a> </p>
								
							</div>
						
						</div>

					 </div><!-- #tab2 -->
					 
					 <div id="tab3" class="tab_content"> 

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">John Doe</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title="">Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Karl Voch</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title=""> Quisque fringilla risus nec libero consectetur at laoreet felis varius. Vivamus adipiscing sollicitudin lectus vitae sit amet ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Vivian Li</a></span> commented on <a href="#">Inspirational</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title="">Phasellus at eros eget felis fringilla ultrices. Morbi pellentesque mattis leo in molestie ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Francis Flaubert</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title="">Vivamus vestibulum enim sit amet dolor rhoncus sodales. Aenean ut odio mauris eget felis  ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Gotze Mallermung</a></span> commented on <a href="#">Curagitur</a> - <span class="meta">Jun 24, 2012</span></p>
								<p class="italic"><a href="#" title="">Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor ...</a></p>
								
							</div>
						
						</div>

					 </div><!-- #tab3 -->
					 
				 </div> <!-- .tab_container --> 
				
			</div>
			
			<div class="widget_120_container">
			
				<div class="blogroll">
				
					<h1>Blogroll</h1>
					
					<ul>
						<li><a href="#" title="">Documentation</a></li>
						<li><a href="#" title="">Plugins</a></li>
						<li><a href="#" title="">Suggest Ideas</a></li>
						<li><a href="#" title="">Support Forum</a></li>
						<li><a href="#" title="">Themes</a></li>
						<li><a href="#" title="">WordPress Blog</a></li>
						<li><a href="#" title="">WordPress Planet</a></li>
						<li><a href="#" title="">MagTruetitude</a></li>
						<li><a href="#" title="">Redminton</a></li>
						<li><a href="#" title="">Buy this theme</a></li>
					</ul>
				
				</div>
				
				<div class="ad_120"><a href="#" title="" ><img src="images/120x240.gif" alt="Lorem ipsum" /></a></div>
				<div class="ad_120"><a href="#" title="" ><img src="images/120x240.gif" alt="Lorem ipsum" /></a></div>
			
			</div>
			
			<div class="ad_336">
			
				<div class="ad"><a href="#" title="" ><img src="images/336x280.gif" alt="Lorem ipsum" /></a></div>
				<div class="ad_note"><a href="#" title="Advertise here" >Advertise here</a></div>
				
			</div> 
		
			<div class="copyright">Copyright &copy; 2012 - Blogfest, HTML template by <a href="http://demo.foldingtheme.com/" target="_blank">Folding Theme</a></div>
		
		</div> <!-- sidebar end --> 
		
		<a href="#" class="scrollup">Scroll</a>
		
		<!-- Footer
			================================================== -->
		
		<footer>
		
			<div id="footer">
			
				<div class="footer_menu">
				
					<ul>
						<li><a href="index.html" title="home">Home</a></li>
						<li><a href="faq.html" title="features">Features</a></li>
						<li><a href="portfolio.html" title="portfolio">Portfolio</a></li>
						<li><a href="elements.html" title="styles">Styles</a></li>
						<li><a href="category.html" title="blog">Blog</a></li>
						<li><a href="contact.php" title="contact">Contact</a></li>
					</ul>
				
				</div>
				
				<div class="footer_social">
				
					<ul>
						<li><a href="#" title="" ><img src="images/icon_rss.png" alt="RSS" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_twitter.png" alt="Twitter" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_facebook.png" alt="Facebook" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_deviantart.png" alt="DevianART" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_vimeo.png" alt="Vimeo" /></a></li>
					</ul>
				
				</div>
			
			</div>

		</footer>

	</div>
  
  
	<!-- Scripts
        ================================================== -->
		
		<script src="js/jquery-1.7.1.min.js"></script>
		<script>window.jQuery || document.write('<script src="js/jquery-1.7.min.js">\x3C/script>')</script>
		<script src="js/make_dropdown.js"></script>
		<script defer src="js/jquery.infieldlabel.min.js"></script>
		<script defer src="js/functions.js"></script>
		<script defer src="js/jquery.flexslider.js"></script>
		<script src="js/jquery.prettyPhoto.js"></script>
		<script src="twitter/jquery.tweet.js"></script>

		<script type="text/javascript">
		
			jQuery.noConflict();
			
			jQuery(window).load(function() {
				
				jQuery('.flexslider').flexslider({
					animationLoop: false,
					controlNav: false, 
					animation: "slide",
				});
			
				// lightbox
				jQuery("a[data-rel^='prettyPhoto']").prettyPhoto();
				
			});	
		
		</script>
		
</body>
</html>