<span id="ad728" class="mid"></span>				
		</div>
		
		<!--===== Sidebar======-->
		
		<div id="sidebar">
		
<div class="social_and_search">

<span id="social" class="mid"></span>			
			

<span id="search" class="mid"></span>							
			
			</div>
<span id="article_widget" class="mid"></span>						
		
			
		</div> <!-- sidebar end --> 
		
		<div class="error_404">
			
			<h1 class="error_404">Whoops!</h1>
			<h1 class="no_border">The page you are looking for has been moved or doesn't exist anymore.</h1>
			<p>If you followed a link, it’s probably broken. Please <a href="contact.html">contact us</a> and we’ll fix it.</p>
		
		</div>
		
		<a href="#" class="scrollup">Scroll</a>
		
	</div>