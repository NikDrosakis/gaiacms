
			<!-- POSTS LISTINGS start here 
			================================================== -->
			
<?php $this->page()->module('portfolio_col2'); ?>
			
		</div>
		
		<!-- Sidebar
			================================================== -->
		
		<div id="sidebar">
		
			<div class="social_counter">
			

<?php $this->page()->module('social_follow'); ?>		
			
			
<div class="social_and_subscribe">
				
<?php $this->page()->module('social'); ?>					
<?php $this->page()->module('subscribe'); ?>
				
</div>
			
</div>
			
<?php $this->page()->module('article_widget'); ?>

<?php $this->page()->module('tab_widget'); ?>			