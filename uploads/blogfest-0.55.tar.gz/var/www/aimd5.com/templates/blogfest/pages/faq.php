<!-- POSTS LISTINGS start here
			================================================== -->
			
<div class="post_container">
			
<?php $this->page()->module('accordion'); ?>				
			
</div>
			
<!-- POSTS LISTINGS end here 
			================================================== -->
		
		</div>
		
		<!-- Sidebar
			================================================== -->
		
		<div id="sidebar">
		
			<div class="social_counter">
			
<?php $this->page()->module('social_follow'); ?>
			
<div class="social_and_subscribe">
				
<?php $this->page()->module('social'); ?>
					
<?php $this->page()->module('subscribe'); ?>				
				
</div>
			
</div>
			
<?php $this->page()->module('article_widget'); ?>
				
<?php $this->page()->module('ad200'); ?>