<?php

// set correct path!
require_once( 'getTwitterFollowers.php' );
// change screen name to yours
echo getTwitterFollowers('YOUR TWITTER USERNAME');

?>

