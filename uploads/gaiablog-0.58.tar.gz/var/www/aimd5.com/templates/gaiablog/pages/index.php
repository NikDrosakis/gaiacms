    <!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
    <!---<script src="/gaia/js/init.js"></script>--->
    <script src="/templates/gaiablog/js/jquery.scrolly.min.js"></script>
    <script src="/templates/gaiablog/js/skel.min.js"></script>
    <script src="/templates/gaiablog/js/init.js"></script>

    <noscript>
        <link rel="stylesheet" href="/templates/gaiablog/css/skel.css" />
        <link rel="stylesheet" href="/templates/gaiablog/css/style.css" />
        <link rel="stylesheet" href="/templates/gaiablog/css/style-desktop.css" />
    </noscript>
    <!--[if lte IE 8]><link rel="stylesheet" href="/templates/gaiablog/css/ie/v8.css" /><![endif]-->
    <!--[if lte IE 9]><link rel="stylesheet" href="/templates/gaiablog/css/ie/v9.css" /><![endif]-->

<!-- Nav -->
<nav id="nav">
    <ul class="container">
        <li><a href="#top">Top</a></li>
        <li><a href="#work">Work</a></li>
        <li><a href="#portfolio">Portfolio</a></li>
        <li><a href="#contact">Contact</a></li>
    </ul>

</nav>

<!-- Home -->
<div class="wrapper style1 first">
	<article class="container" id="top">
		<div class="row">
			<div class="4u">
				<span class="image fit"><img src="/templates/gaiablog/images/pic00.jpg" alt="" /></span>
			</div>
			<div class="8u">
				<header>
					<h1 id="h1_1"><?=$this->is('h1_1');?><!--APPEND h1_1---></strong></h1>
				</header>
				<p id="p_1"><?=$this->is('p_1');?><!--APPEND p_1---></p>
				<a href="#work" class="button big scrolly" id="a_1"><?=$this->is('a_1');?></a>
			</div>
		</div>
	</article>
</div>

<!-- Work -->
<div class="wrapper style2">
	<article id="work">
		<header>
			<h2 id="h2_1"><?=$this->is('h2_1');?></h2>
			<p id="p_2"><?=$this->is('p_2');?></p>
		</header>
		<div class="container">
			<div class="row">
				<div class="4u">
					<section class="box style1">
						<span class="icon featured fa-comments-o"></span>
						<h3 id="h3_1"><?=$this->is('h3_1');?></h3>
						<p id="p_3">Ornare nulla proin odio consequat sapien vestibulum ipsum primis sed amet consequat lorem dolore.</p>
					</section>
				</div>
				<div class="4u">
					<section class="box style1">
						<span class="icon featured fa-camera-retro"></span>
						<h3>Lorem dolor tempus</h3>
						<p id="p_4"><?=$this->is('p_4');?></p>
					</section>
				</div>
				<div class="4u">
					<section class="box style1">
						<span class="icon featured fa-thumbs-o-up"></span>
						<h3>Feugiat posuere</h3>
						<p id="p_5"><?=$this->is('p_5');?></p>
					</section>
				</div>
			</div>
		</div>
		<footer>
			<p id="p_6">Lorem ipsum dolor sit sapien vestibulum ipsum primis?</p>
			<a href="#portfolio" class="button big scrolly">See some of my recent work</a>
		</footer>
	</article>
</div>

<!-- Portfolio -->
<div class="wrapper style3">
	<article id="portfolio">
		<header>
			<h2>Here’s some stuff I made recently.</h2>
			<p>Proin odio consequat  sapien vestibulum consequat lorem dolore feugiat lorem ipsum dolore.</p>
		</header>
		<div class="container">
			<div class="row">
				<div class="4u">
					<article class="box style2">
						<a href="#" class="image featured"><img src="/templates/gaiablog/images/pic01.jpg" alt="" /></a>
						<h3><a href="#">Magna feugiat</a></h3>
						<p>Ornare nulla proin odio consequat.</p>
					</article>
				</div>
				<div class="4u">
					<article class="box style2">
						<a href="#" class="image featured"><img src="/templates/gaiablog/images/pic02.jpg" alt="" /></a>
						<h3><a href="#">Veroeros primis</a></h3>
						<p>Ornare nulla proin odio consequat.</p>
					</article>
				</div>
				<div class="4u">
					<article class="box style2">
						<a href="#" class="image featured"><img src="/templates/gaiablog/images/pic03.jpg" alt="" /></a>
						<h3><a href="#">Lorem ipsum</a></h3>
						<p>Ornare nulla proin odio consequat.</p>
					</article>
				</div>
			</div>
			<div class="row">
				<div class="4u">
					<article class="box style2">
						<a href="#" class="image featured"><img src="/templates/gaiablog/images/pic04.jpg" alt="" /></a>
						<h3><a href="#">Tempus dolore</a></h3>
						<p>Ornare nulla proin odio consequat.</p>
					</article>
				</div>
				<div class="4u">
					<article class="box style2">
						<a href="#" class="image featured"><img src="/templates/gaiablog/images/pic05.jpg" alt="" /></a>
						<h3><a href="#">Feugiat aliquam</a></h3>
						<p>Ornare nulla proin odio consequat.</p>
					</article>
				</div>
				<div class="4u">
					<article class="box style2">
						<a href="#" class="image featured"><img src="/templates/gaiablog/images/pic06.jpg" alt="" /></a>
						<h3><a href="#">Sed amet ornare</a></h3>
						<p>Ornare nulla proin odio consequat.</p>
					</article>
				</div>
			</div>
		</div>
		<footer>
			<p>Lorem ipsum dolor sit sapien vestibulum ipsum primis?</p>
			<a href="#contact" class="button big scrolly">Get in touch with me</a>
		</footer>
	</article>
</div>

<!-- Contact -->
<div class="wrapper style4">
	<article id="contact" class="container small">
		<header>
			<h2>Have me make stuff for you.</h2>
			<p>Ornare nulla proin odio consequat sapien vestibulum ipsum sed lorem.</p>
		</header>


		<div>
<?php $this->page()->module('contact'); ?>



			<div class="row">
				<div class="12u">
					<hr />
					<h3>Find me on ...</h3>
					<ul class="social">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
						<li><a href="#" class="icon fa-linkedin"><span class="label">LinkedIn</span></a></li>
						<li><a href="#" class="icon fa-tumblr"><span class="label">Tumblr</span></a></li>
						<li><a href="#" class="icon fa-google-plus"><span class="label">Google+</span></a></li>
						<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
						<!--
                        <li><a href="#" class="icon fa-rss"><span>RSS</span></a></li>
                        <li><a href="#" class="icon fa-instagram"><span>Instagram</span></a></li>
                        <li><a href="#" class="icon fa-foursquare"><span>Foursquare</span></a></li>
                        <li><a href="#" class="icon fa-skype"><span>Skype</span></a></li>
                        <li><a href="#" class="icon fa-soundcloud"><span>Soundcloud</span></a></li>
                        <li><a href="#" class="icon fa-youtube"><span>YouTube</span></a></li>
                        <li><a href="#" class="icon fa-blogger"><span>Blogger</span></a></li>
                        <li><a href="#" class="icon fa-flickr"><span>Flickr</span></a></li>
                        <li><a href="#" class="icon fa-vimeo"><span>Vimeo</span></a></li>
                        -->
					</ul>
					<hr />
				</div>
			</div>
		</div>

<footer>
    <ul id="copyright">
        <li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
    </ul>
</footer>
</article>
</div>