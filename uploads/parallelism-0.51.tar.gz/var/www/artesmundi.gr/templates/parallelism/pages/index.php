		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="/templates/<?=$this->template?>/js/jquery.poptrox.min.js"></script>
		<script src="/templates/<?=$this->template?>/js/skel.min.js"></script>
		<script src="/templates/<?=$this->template?>/js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="/templates/<?=$this->template?>/css/skel.css" />
			<link rel="stylesheet" href="/templates/<?=$this->template?>/css/style.css" />
			<link rel="stylesheet" href="/templates/<?=$this->template?>/css/style-desktop.css" />
			<link rel="stylesheet" href="/templates/<?=$this->template?>/css/style-noscript.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="/templates/<?=$this->template?>/css/ie/v8.css" /><![endif]-->

		<div id="wrapper">

			<div id="main">
				<div id="reel">

					<!-- Header Item -->
					
						<div id="header" class="item" data-width="400">
							<div class="inner">
								<h1>Parallelism</h1>
								<p>A responsive portfolio site<br />
								template by HTML5 UP</p>
							</div>
						</div>
					
					<!-- Thumb Items -->

						<article class="item thumb" data-width="282">
							<h2>You really got me</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/01.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/01.jpg" alt=""></a>
						</article>
						
						<article class="item thumb" data-width="384">
							<h2>Ad Infinitum</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/02.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/02.jpg" alt=""></a>
						</article>
						
						<article class="item thumb" data-width="274">
							<h2>Different.</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/03.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/03.jpg" alt=""></a>
						</article>
						
						<article class="item thumb" data-width="282">
							<h2>Elysium</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/04.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/04.jpg" alt=""></a>
						</article>
						
						<article class="item thumb" data-width="476">
							<h2>Kingdom of the Wind</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/05.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/05.jpg" alt=""></a>
						</article>
						
						<article class="item thumb" data-width="232">
							<h2>The Pursuit</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/06.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/06.jpg" alt=""></a>
						</article>
						
						<article class="item thumb" data-width="352">
							<h2>Boundless</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/07.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/07.jpg" alt=""></a>
						</article>
						
						<article class="item thumb" data-width="348">
							<h2>The Spectators</h2>
							<a href="/templates/<?=$this->template?>/images/fulls/08.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/08.jpg" alt=""></a>
						</article>

					<!-- Filler Thumb Items (just for demonstration purposes) -->
						<article class="item thumb" data-width="476"><h2>Kingdom of the Wind</h2><a href="/templates/<?=$this->template?>/images/fulls/05.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/05.jpg" alt=""></a></article>
						<article class="item thumb" data-width="232"><h2>The Pursuit</h2><a href="/templates/<?=$this->template?>/images/fulls/06.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/06.jpg" alt=""></a></article>
						<article class="item thumb" data-width="352"><h2>Boundless</h2><a href="/templates/<?=$this->template?>/images/fulls/07.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/07.jpg" alt=""></a></article>
						<article class="item thumb" data-width="348"><h2>The Spectators</h2><a href="/templates/<?=$this->template?>/images/fulls/08.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/08.jpg" alt=""></a></article>
						<article class="item thumb" data-width="282"><h2>You really got me</h2><a href="/templates/<?=$this->template?>/images/fulls/01.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/01.jpg" alt=""></a></article>
						<article class="item thumb" data-width="384"><h2>Ad Infinitum</h2><a href="/templates/<?=$this->template?>/images/fulls/02.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/02.jpg" alt=""></a></article>
						<article class="item thumb" data-width="274"><h2>Different.</h2><a href="/templates/<?=$this->template?>/images/fulls/03.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/03.jpg" alt=""></a></article>
						<article class="item thumb" data-width="282"><h2>Elysium</h2><a href="/templates/<?=$this->template?>/images/fulls/04.jpg"><img src="/templates/<?=$this->template?>/images/thumbs/04.jpg" alt=""></a></article>

				</div>
			</div>
		
			<div id="footer">
				<div class="left">
					<p>This is <strong>Parallelism</strong>, a responsive portfolio site template by <a href="http://html5up.net">HTML5 UP</a>. Free for personal<br />
					and commercial use under the <a href="http://html5up.net/license">Creative Commons Attribution</a> license.</p>
				</div>
				<div class="right">
					<ul class="contact">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
						<li><a href="#" class="icon fa-pinterest"><span class="label">Pinterest</span></a></li>
						<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
					</ul>
					<ul class="copyright">
						<li>© Untitled</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</div>
			</div>

		</div>

	</body>
</html>