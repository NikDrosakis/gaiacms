<!-- Footer -->
<footer id="footer">
    <p class="copyright">&copy; Nikos Drosakis. All rights reserved. Powered by <a href="http://gaiasys.com">Gaiasys</a>. Design: <a href="https://html5up.net">HTML5 UP</a>.</p>
</footer>

</div>
</div>


<!-- Scripts -->
<script src="/templates/editorial/assets/js/skel.min.js"></script>
<script src="/templates/editorial/assets/js/util.js"></script>
<!--[if lte IE 8]><script src="/templates/editorial/assets/js/ie/respond.min.js"></script><![endif]-->
<script src="/templates/editorial/assets/js/main.js"></script>

</body>
</html>