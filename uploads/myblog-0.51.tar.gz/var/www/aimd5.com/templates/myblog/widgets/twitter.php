<?php //updated:2020-01-07 23:07:49 twitter- v.0.67 - Author:Nikos Drosakis - License: GPL License ?>
<div style="margin:0 auto">
    <a class="twitter-timeline" href="https://twitter.com/gaiasyscom">Tweets by gaiasyscom</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
    <div>