    <!-- Main 333-->
    <div id="main">
        <div class="inner">

            <!-- Header -->
            <header id="header">
                <a href="/" class="logo"><strong id="pvar108" class="pvar" ></strong></a>
                <ul class="icons">
                    <li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
                    <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
                    <li><a href="#" class="icon fa-snapchat-ghost"><span class="label">Snapchat</span></a></li>
                    <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
                    <li><a href="#" class="icon fa-medium"><span class="label">Medium</span></a></li>
                </ul>
            </header>

            <!-- Banner -->
            <section id="banner">
                <div class="content">
                    <header>
                        <h1>Welcome</h1>
                        <p>Summary</p>
                    </header>
                    <p  id="pvar90" class="pvar"></p>
                    <ul class="actions">
                        <li><a href="#" class="button big">Learn More</a></li>
                    </ul>
                </div>
                <span class="image object">
										<img  id="pvar109" class="pvar" alt="" />
									</span>
            </section>

            <!-- Section -->
<!--            <section>-->
<!--                <header class="major">-->
<!--                    <h2>Erat lacinia</h2>-->
<!--                </header>-->
<!--                <div class="features">-->
<!--                    <article>-->
<!--                        <span class="icon fa-diamond"></span>-->
<!--                        <div class="content">-->
<!--                            <h3>Portitor ullamcorper</h3>-->
<!--                            <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        </div>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <span class="icon fa-paper-plane"></span>-->
<!--                        <div class="content">-->
<!--                            <h3>Sapien veroeros</h3>-->
<!--                            <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        </div>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <span class="icon fa-rocket"></span>-->
<!--                        <div class="content">-->
<!--                            <h3>Quam lorem ipsum</h3>-->
<!--                            <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        </div>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <span class="icon fa-signal"></span>-->
<!--                        <div class="content">-->
<!--                            <h3>Sed magna finibus</h3>-->
<!--                            <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        </div>-->
<!--                    </article>-->
<!--                </div>-->
<!--            </section>-->

            <!-- Section -->
<!--            <section>-->
<!--                <header class="major">-->
<!--                    <h2>Ipsum sed dolor</h2>-->
<!--                </header>-->
<!--                <div class="posts">-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic01.jpg" alt="" /></a>-->
<!--                        <h3>Interdum aenean</h3>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        <ul class="actions">-->
<!--                            <li><a href="#" class="button">More</a></li>-->
<!--                        </ul>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic02.jpg" alt="" /></a>-->
<!--                        <h3>Nulla amet dolore</h3>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        <ul class="actions">-->
<!--                            <li><a href="#" class="button">More</a></li>-->
<!--                        </ul>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic03.jpg" alt="" /></a>-->
<!--                        <h3>Tempus ullamcorper</h3>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        <ul class="actions">-->
<!--                            <li><a href="#" class="button">More</a></li>-->
<!--                        </ul>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic04.jpg" alt="" /></a>-->
<!--                        <h3>Sed etiam facilis</h3>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        <ul class="actions">-->
<!--                            <li><a href="#" class="button">More</a></li>-->
<!--                        </ul>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic05.jpg" alt="" /></a>-->
<!--                        <h3>Feugiat lorem aenean</h3>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        <ul class="actions">-->
<!--                            <li><a href="#" class="button">More</a></li>-->
<!--                        </ul>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic06.jpg" alt="" /></a>-->
<!--                        <h3>Amet varius aliquam</h3>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                        <ul class="actions">-->
<!--                            <li><a href="#" class="button">More</a></li>-->
<!--                        </ul>-->
<!--                    </article>-->
<!--                </div>-->
<!--            </section>-->

        </div>
    </div>

    <!-- Sidebar -->
    <div id="sidebar">
        <div class="inner">


            <!-- Menu -->
            <nav id="menu"><?php $this->module('search'); ?>
<!--                <header class="major">-->
<!--                    <h2>Menu</h2>-->
<!--                </header>-->
<!--                <ul>-->
<!--                    <li><a href="/">Homepage</a></li>-->
<!--                    <li><a href="/cv-programming">Artistic Curriculum</a></li>-->
<!--                    <li><a href="/cv-artistic">Programming Curriculum</a></li>-->
<!--                    <li>-->
<!--                        <span class="opener">Stage Actor</span>-->
<!--                        <ul>-->
<!--                            <li><a href="#">Lorem Dolor</a></li>-->
<!--                            <li><a href="#">Ipsum Adipiscing</a></li>-->
<!--                            <li><a href="#">Tempus Magna</a></li>-->
<!--                            <li><a href="#">Feugiat Veroeros</a></li>-->
<!--                        </ul>-->
<!--                    </li>-->
<!--                    <li>-->
<!--                        <span class="opener">Directing</span>-->
<!--                        <ul>-->
<!--                            <li><a href="#">Lorem Dolor</a></li>-->
<!--                            <li><a href="#">Ipsum Adipiscing</a></li>-->
<!--                            <li><a href="#">Tempus Magna</a></li>-->
<!--                            <li><a href="#">Feugiat Veroeros</a></li>-->
<!--                        </ul>-->
<!--                    </li>-->
<!--                    <li><a href="#">Programming</a></li>-->
<!--                </ul>-->
            </nav>

            <!-- Section -->
<!--            <section>-->
<!--                <header class="major">-->
<!--                    <h2>Ante interdum</h2>-->
<!--                </header>-->
<!--                <div class="mini-posts">-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic07.jpg" alt="" /></a>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic08.jpg" alt="" /></a>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>-->
<!--                    </article>-->
<!--                    <article>-->
<!--                        <a href="#" class="image"><img src="/templates/editorial/images/pic09.jpg" alt="" /></a>-->
<!--                        <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>-->
<!--                    </article>-->
<!--                </div>-->
<!--                <ul class="actions">-->
<!--                    <li><a href="#" class="button">More</a></li>-->
<!--                </ul>-->
<!--            </section>-->

            <!-- Section -->
<!--            <section>-->
<!--                <header class="major">-->
<!--                    <h2>Get in touch</h2>-->
<!--                </header>-->
<!--                <p>Sed varius enim lorem ullamcorper dolore aliquam aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore. Proin sed aliquam facilisis ante interdum. Sed nulla amet lorem feugiat tempus aliquam.</p>-->
<!--                <ul class="contact">-->
<!--                    <li class="fa-envelope-o"><a href="#">information@untitled.tld</a></li>-->
<!--                    <li class="fa-phone">(000) 000-0000</li>-->
<!--                    <li class="fa-home">1234 Somewhere Road #8254<br />-->
<!--                        Nashville, TN 00000-0000</li>-->
<!--                </ul>-->
<!--            </section>-->


