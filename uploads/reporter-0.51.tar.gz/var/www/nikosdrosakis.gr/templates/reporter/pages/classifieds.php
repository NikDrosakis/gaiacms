			<div class="main-content">
				<div class="col-md-9 total-news">
<?php $this->page()->module('classifieds'); ?>
				</div>	
				<div class="col-md-3 side-bar">
<?php $this->page()->module('videos'); ?>
<?php $this->page()->module('signup'); ?>
					<div class="clearfix"></div>
<?php $this->page()->module('popular'); ?>
<?php $this->page()->module('subscribe-now'); ?>

					<div class="clearfix"></div>
				</div>	
				<div class="clearfix"></div>
			</div>
