			<div class="main-content">
				<div class="col-md-9 total-news">
	<?php $this->page()->module('live-markets'); ?>				

				<div class="posts">
					<div class="left-posts">
<?php $this->page()->module('world-news'); ?>	
<?php $this->page()->module('latest-articles'); ?>
<?php $this->page()->module('gallery'); ?>
<?php $this->page()->module('tech-news'); ?>												
					</div>
					<div class="right-posts">
<?php $this->page()->module('editorial'); ?>						
					</div>
					<div class="clearfix"></div>	
				</div>
				</div>	
				
				<div class="col-md-3 side-bar">
<?php $this->page()->module('videos'); ?>
<?php $this->page()->module('signup'); ?>

					<div class="clearfix"></div>
<?php $this->page()->module('popular'); ?>
<?php $this->page()->module('subscribe-now'); ?>				

					<div class="clearfix"></div>
				</div>	
				<div class="clearfix"></div>
			</div>
