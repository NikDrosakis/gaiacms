			

<?php $post= $this->post()->one($this->GS['mode']);?>
<div class="movie-main-content">
				<div class="col-md-9 total-news">
					
	<div class="grids">
		<div class="msingle-grid box">
			<div class="grid-header">
				<h3><?=$post['title']?></h3>
				<ul>
				<li><span><?=$post['excerpt']?></span></li>
				<li><a href="#">5 comments</a></li>
				</ul>
			</div>
			<div class="singlepage">
			<a href="#"><img id="pvar61" src="/templates/reporter/images/m1.jpg" /></a>
							<p><?=$post['content']?></p>
							<div class="clearfix"> </div>
						</div>
						<div class="single">
							<h3><?=$post['title']?></h3>
							<p><?=$post['subtitle']?></p>
						</div>
							<div class="best-review">
								<h4  id="pvar65" ></h4>
								<p id="pvar66" ></p>
								<p id="pvar67" ></p>
							</div>
							<div class="story-review">
								<h4>REVIEW:</h4>
								<p id="pvar63" ></p>
							</div>
		</div>
	
			<div class="clearfix"> </div>
	</div>
<?php $this->page()->module('comment'); ?>
			</div>	
				<div class="col-md-3 side-bar">
<?php $this->page()->module('might'); ?>
<?php $this->page()->module('featured'); ?>
						<div class="clearfix"></div>
<?php $this->page()->module('popular'); ?>
<?php $this->page()->module('subscribe-now'); ?>
<?php include TEMPLATES."reporter/modules/popular.php";?>
		<div class="clearfix"></div>
<?php $this->page()->module('archives'); ?>
				</div>	
		<div class="clearfix"></div>
			</div>
