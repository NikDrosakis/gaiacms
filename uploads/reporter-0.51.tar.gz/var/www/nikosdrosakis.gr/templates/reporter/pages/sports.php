			<div class="main-content">
				<div class="col-md-9 total-news">
<?php $this->page()->module('slider2'); ?>

						  <div class="sports-top">
							<div class="s-grid-left">
<?php $this->page()->module('cricket'); ?>
								</div>
							<div class="s-grid-right">
<?php $this->page()->module('cricket'); ?>
								</div>
								<div class="clearfix"></div>
							</div>
						  <div class="sports-top">
							<div class="s-grid-left">
<?php $this->page()->module('cricket'); ?>
								</div>
							<div class="s-grid-right">
<?php $this->page()->module('cricket'); ?>
								</div>
								<div class="clearfix"></div>
							</div>
<?php $this->page()->module('photos'); ?>
						  </div>
				</div>	
				<div class="col-md-3 side-bar">
<?php $this->page()->module('videos'); ?>
<?php $this->page()->module('signup'); ?>
					<div class="clearfix"></div>
<?php $this->page()->module('popular'); ?>
<?php $this->page()->module('subscribe-now'); ?>

					<div class="clearfix"></div>
				</div>	
				<div class="clearfix"></div>
