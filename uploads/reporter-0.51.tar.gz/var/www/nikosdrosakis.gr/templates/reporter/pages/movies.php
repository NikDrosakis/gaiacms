			<div class="main-content">
				<div class="col-md-9 total-news">
					<?php include TEMPLATES."reporter/modules/slider.php";?>
				<div class="posts">
					<div class="mright-posts">

						<?php include TEMPLATES."reporter/modules/desk.php";?>
						<?php include TEMPLATES."reporter/modules/editorial.php";?>
					</div>
					<div class="mleft-posts">
						<?php include TEMPLATES."reporter/modules/mlatest-articles.php";?>
						<?php include TEMPLATES."reporter/modules/world-news.php";?>
						<?php include TEMPLATES."reporter/modules/gallery.php";?>
						<?php include TEMPLATES."reporter/modules/tech-news.php";?>
					</div>
					<div class="clearfix"></div>	
				</div>
				</div>	
				<div class="col-md-3 side-bar">
<?php include TEMPLATES."reporter/modules/might.php";?>
<?php include TEMPLATES."reporter/modules/featured.php";?>

						<div class="clearfix"></div>

<?php include TEMPLATES."reporter/modules/popular.php";?>
<?php include TEMPLATES."reporter/modules/subscribe-now.php";?>
					<div class="clearfix"></div>

<?php include TEMPLATES."reporter/modules/archives.php";?>
				</div>	
				<div class="clearfix"></div>
			</div>
