<div class="footer text-center">
    <div class="bottom-menu">
        <ul><
            <li><a href="index">World  News</a></li> |
            <li><a href="sports">Sports</a></li> |
            <li><a href="tech">Techology</a></li> |
            <li><a href="business">Business</a></li> |
            <li><a href="movies">Movies</a></li> |
            <li><a href="movies">Entertainment</a></li> |
            <li><a href="books">Books</a></li> |
            <li><a href="movies">Culture</a></li> |
            <li><a href="classifieds">Classifieds</a></li> |
            <li><a href="blogs">Blogs</a></li>
        </ul>
    </div>
    <div class="copyright text-center">
        <p>The News Reporter © 2015 All rights reserved | Template by  <a href="http://w3layouts.com">W3layouts</a></p>
    </div>
</div>
</div>
</div>
</body>
</html>