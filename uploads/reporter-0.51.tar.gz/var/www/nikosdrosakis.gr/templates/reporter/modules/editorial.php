<div class="editorial">
    <h3>editorial</h3>
    <div class="editor">
        <a href="single"><img src="/templates/reporter/images/e1.jpg" alt="" /></a>
        <a href="single">Lorem ipsum dolor sit amet con se cte tur adipiscing elit</a>
    </div>
    <div class="editor">
        <a href="single"><img src="/templates/reporter/images/e2.jpg" alt="" /></a>
        <a href="single">Lorem ipsum dolor sit amet con se cte tur adipiscing elit</a>
    </div>
    <div class="editor">
        <a href="single"><img src="/templates/reporter/images/e1.jpg" alt="" /></a>
        <a href="single">Lorem ipsum dolor sit amet con se cte tur adipiscing elit</a>
    </div>
    <div class="editor">
        <a href="single"><img src="/templates/reporter/images/e3.jpg" alt="" /></a>
        <a href="single">Lorem ipsum dolor sit amet con se cte tur adipiscing elit</a>
    </div>
</div>