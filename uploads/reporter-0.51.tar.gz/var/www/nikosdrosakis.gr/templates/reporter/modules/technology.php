<div class="technology">
    <div class="tech-main">
        <div class="col-md-4 tech">
            <a href="singlepage"><img src="/templates/reporter/images/tech4.jpg" alt="" /></a>
            <a class="power" href="singlepage">You can still get into trouble for online posts: Digital law experts</a>
        </div>
        <div class="col-md-4 tech">
            <a href="singlepage"><img src="/templates/reporter/images/tech5.jpg" alt="" /></a>
            <a class="power" href="singlepage">Indian online buyers among world's unhappiest: UN</a>
        </div>
        <div class="col-md-4 tech">
            <a href="singlepage"><img src="/templates/reporter/images/tech6.jpg" alt="" /></a>
            <a class="power" href="singlepage">10 mistakes that will kill your startup</a>
        </div>
        <div class="clearfix"></div>
    </div>
</div>