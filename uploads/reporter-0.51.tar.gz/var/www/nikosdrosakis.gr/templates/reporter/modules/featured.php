<div class="featured">
    <h3>Featured Today in Movie Reviews</h3>
    <ul>
        <li>
            <a href="single"><img src="/templates/reporter/images/f1.jpg" alt="" /></a>
            <p>lorem movie review</p>
        </li>
        <li>
            <a href="single"><img src="/templates/reporter/images/f2.jpg" alt="" /></a>
            <p>lorem movie review</p>
        </li>
        <li>
            <a href="single"><img src="/templates/reporter/images/f3.jpg" alt="" /></a>
            <p>lorem movie review</p>
        </li>
        <li>
            <a href="single"><img src="/templates/reporter/images/f4.jpg" alt="" /></a>
            <p>lorem movie review</p>
        </li>
        <li>
            <a href="single"><img src="/templates/reporter/images/f5.jpg" alt="" /></a>
            <p>lorem movie review</p>
        </li>
        <li>
            <a href="single"><img src="/templates/reporter/images/f6.jpg" alt="" /></a>
            <p>lorem movie review</p>
        </li>
        <div class="clearfix"></div>
    </ul>
</div>