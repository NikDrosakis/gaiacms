<div class="gallery">
    <div class="main-title-head">
        <h3>gallery</h3>
        <a href="single">More  +</a>
        <div class="clearfix"></div>
    </div>
    <div class="gallery-images">
        <div class="course_demo1">
            <ul id="flexiselDemo1">
                <li>
                    <a href="single"><img src="/templates/reporter/images/mg1.jpg" alt="" /></a>
                </li>
                <li>
                    <a href="single"><img src="/templates/reporter/images/mg2.jpg" alt="" /></a>
                </li>
                <li>
                    <a href="single"><img src="/templates/reporter/images/mg3.jpg" alt="" /></a>
                </li>
                <li>
                    <a href="single"><img src="/templates/reporter/images/mg4.jpg" alt="" /></a>
                </li>
            </ul>
        </div>
        <link rel="stylesheet" href="/templates/reporter/css/flexslider.css" type="text/css" media="screen" />
        <script type="text/javascript">
            $(window).load(function() {
                $("#flexiselDemo1").flexisel({
                    visibleItems: 3,
                    animationSpeed: 1000,
                    autoPlay: true,
                    autoPlaySpeed: 3000,
                    pauseOnHover: true,
                    enableResponsiveBreakpoints: true,
                    responsiveBreakpoints: {
                        portrait: {
                            changePoint:480,
                            visibleItems: 2
                        },
                        landscape: {
                            changePoint:640,
                            visibleItems: 2
                        },
                        tablet: {
                            changePoint:768,
                            visibleItems: 3
                        }
                    }
                });

            });
        </script>
        <script type="text/javascript" src="/templates/reporter/js/jquery.flexisel.js"></script>
    </div>
    <div class="course_demo1">
        <ul id="flexiselDemo">
            <li>
                <a href="single"><img src="/templates/reporter/images/mg7.jpg" alt="" /></a>
            </li>
            <li>
                <a href="single"><img src="/templates/reporter/images/mg5.jpg" alt="" /></a>
            </li>
            <li>
                <a href="single"><img src="/templates/reporter/images/mg6.jpg" alt="" /></a>
            </li>
            <li>
                <a href="single"><img src="/templates/reporter/images/mg8.jpg" alt="" /></a>
            </li>
            <li>
                <a href="single"><img src="/templates/reporter/images/g2.jpg" alt="" /></a>
            </li>
        </ul>
    </div>
    <link rel="stylesheet" href="/templates/reporter/css/flexslider.css" type="text/css" media="screen" />
    <script type="text/javascript">
        $(window).load(function() {
            $("#flexiselDemo").flexisel({
                visibleItems: 3,
                animationSpeed: 1000,
                autoPlay: true,
                autoPlaySpeed: 3000,
                pauseOnHover: true,
                enableResponsiveBreakpoints: true,
                responsiveBreakpoints: {
                    portrait: {
                        changePoint:480,
                        visibleItems: 2
                    },
                    landscape: {
                        changePoint:640,
                        visibleItems: 2
                    },
                    tablet: {
                        changePoint:768,
                        visibleItems: 3
                    }
                }
            });

        });
    </script>
    <script type="text/javascript" src="/templates/reporter/js/jquery.flexisel.js"></script>

</div>