<div class="photos">
    <h3>PHOTOS</h3>

    <div class="course_demo1">
        <ul id="flexiselDemo">
            <li>
                <a href="single"><img src="/templates/reporter/images/sg4.jpg" alt="" /></a>
            </li>
            <li>
                <a href="single"><img src="/templates/reporter/images/sg5.jpg" alt="" /></a>
            </li>
            <li>
                <a href="single"><img src="/templates/reporter/images/sg6.jpg" alt="" /></a>
            </li>
            <li>
                <a href="single"><img src="/templates/reporter/images/sg1.jpg" alt="" /></a>
            </li>
        </ul>
    </div>
    <link rel="stylesheet" href="/templates/reporter/css/flexslider.css" type="text/css" media="screen" />
    <script type="text/javascript">
        $(window).load(function() {
            $("#flexiselDemo").flexisel({
                visibleItems: 4,
                animationSpeed: 1000,
                autoPlay: true,
                autoPlaySpeed: 3000,
                pauseOnHover: true,
                enableResponsiveBreakpoints: true,
                responsiveBreakpoints: {
                    portrait: {
                        changePoint:480,
                        visibleItems: 2
                    },
                    landscape: {
                        changePoint:640,
                        visibleItems: 2
                    },
                    tablet: {
                        changePoint:768,
                        visibleItems: 3
                    }
                }
            });

        });
    </script>
    <script type="text/javascript" src="/templates/reporter/js/jquery.flexisel.js"></script>
</div>