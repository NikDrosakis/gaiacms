<div class="sign_up text-center">
    <h3>Sign  Up  for    Newsletter</h3>
    <p class="sign">Sign up to receive our free newsletters!</p>
    <form>
        <input type="text" class="text" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}">
        <input type="text" class="text" value="Email Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email Address';}">
        <input type="submit" value="submit">
    </form>
    <p class="spam">We do not spam. We value your privacy!</p>
</div>