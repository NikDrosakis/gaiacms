<div class="desk-grid">
    <h3>FROM   THE   desk</h3>
    <div class="desk">
        <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur adipiscing elit </a>
        <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
        <p><a href="single">Read More</a><span>3 hours ago</span></p>
    </div>
    <div class="desk">
        <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur adipiscing elit </a>
        <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
        <p><a href="single">Read More</a><span>3 hours ago</span></p>
    </div>
    <div class="desk">
        <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur adipiscing elit </a>
        <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
        <p><a href="single">Read More</a><span>3 hours ago</span></p>
    </div>
    <a class="more" href="#">More  +</a>
</div>