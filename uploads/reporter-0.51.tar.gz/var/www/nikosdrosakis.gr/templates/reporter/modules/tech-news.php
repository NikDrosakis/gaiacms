<div class="tech-news">
    <div class="main-title-head">
        <h3>tech     news</h3>
        <a href="single">More  +</a>
        <div class="clearfix"></div>
    </div>
    <div class="tech-news-grids">
        <div class="left-tech-news">
            <div class="tech-news-grid span_66">
                <a href="#">Lorem ipsum dolor sit amet conse ctetur adipiscing elit  </a>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor ...by <a href="#">John Doe </a>  |  29 comments</p>
            </div>
            <div class="tech-news-grid">
                <h4>Lorem ipsum dolor sit amet conse ctetur adipiscing elit  </h4>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor ...by <a href="#">John Doe </a>  |  29 comments</p>
            </div>
        </div>
        <div class="right-tech-news">
            <div class="tech-news-grid span_66">
                <a href="#">Lorem ipsum dolor sit amet conse ctetur adipiscing elit  </a>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor ...by <a href="#">John Doe </a>  |  29 comments</p>
            </div>
            <div class="tech-news-grid">
                <a href="#">Lorem ipsum dolor sit amet conse ctetur adipiscing elit  </a>
                <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor ...by <a href="#">John Doe </a>  |  29 comments</p>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>