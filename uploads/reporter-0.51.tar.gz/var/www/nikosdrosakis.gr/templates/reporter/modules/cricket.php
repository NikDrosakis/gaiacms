<div class="cricket">
    <h3>tennis</h3>
    <div class="c-sports-main">
        <div class="c-image">
         <a href="singlepage">
     <img src="/templates/reporter/images/tcrt1.jpg"/></a>
        </div>
        <div class="c-text">
            <p>tennis</p>
            <a class="power" href="singlepage">
Power Reigns Supreme at 11th Cricket World Cup</a>
            <a class="reu" href="singlepage">Reuters</a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="s-grid-small">
        <div class="sc-image">
            <a href="singlepage"><img src="/templates/reporter/images/tcrt2.jpg" alt="" /></a>
        </div>
        <div class="sc-text">
            <p>tennis</p>
            <a class="power" href="singlepage">nternational Cricket Council President Walks out of World Cup Final After Trophy Snub</a>
            <a class="reu" href="singlepage">Press Trust Of India</a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="s-grid-small">
        <div class="sc-image">
            <a href="singlepage"><img src="/templates/reporter/images/tcrt3.jpg" alt="" /></a>
        </div>
        <div class="sc-text">
            <p>tennis</p>
            <a class="power" href="singlepage">nternational Cricket Council President Walks out of World Cup Final After Trophy Snub</a>
            <a class="reu" href="singlepage">Press Trust Of India</a>
        </div>
        <div class="clearfix"></div>
    </div>
</div>