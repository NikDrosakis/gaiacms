<div class="latest-articles">
    <div class="main-title-head">
        <h3>latest    articles</h3>
        <a href="singlepage">More  +</a>
        <div class="clearfix"></div>
    </div>
    <div class="world-news-grids">
        <div class="world-news-grid">
            <img src="/templates/reporter/images/a1.jpg" alt="" />
            <a href="singlepage" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="singlepage">Read More</a>
        </div>
        <div class="world-news-grid">
            <img src="/templates/reporter/images/a2.jpg" alt="" />
            <a href="singlepage" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="singlepage">Read More</a>
        </div>
        <div class="world-news-grid">
            <img src="/templates/reporter/images/a3.jpg" alt="" />
            <a href="singlepage" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="singlepage">Read More</a>
        </div>
        <div class="clearfix"></div>
    </div>
</div>