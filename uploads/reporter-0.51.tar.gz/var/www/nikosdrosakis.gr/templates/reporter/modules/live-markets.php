<div class="live-market">
    <h3><span>live</span> market</h3>
    <div class="bull">
        <a href="#"><img src="/templates/reporter/images/business.jpg" alt="" /></a>
    </div>
    <div class="bull-text">
        <a class="bull1" href="singlepage">Bulls return after eight days; Sensex up 517 points</a>
        <p>Bharti, HDFC, ONGC, ITC and CIL emerge as top gainers</p>
        <ul>
            <li><a href="singlepage">Grandkids sue Vijaypat Singhania over inheritance</a></li>
            <li><a href="singlepage">RBI relaxes norms for NPA provisioning</a></li>
            <li><a href="singlepage">We expect RBI to cut rates by another 75 bps: UBS executive director</a></li>
        </ul>
    </div>
    <div class="clearfix"></div>
</div>
