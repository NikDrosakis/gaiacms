<div class="might">
    <h4>You might also like</h4>
    <div class="might-grid">
        <div class="grid-might">
            <a href="single"><img src="/templates/reporter/images/mi.jpg" class="img-responsive" alt=""> </a>
        </div>
        <div class="might-top">
            <p>Lorem Ipsum is simply typesetting industry.</p>
            <a href="single">Lorem Ipsum <i> </i></a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="might-grid">
        <div class="grid-might">
            <a href="single"><img src="/templates/reporter/images/mi1.jpg" class="img-responsive" alt=""> </a>
        </div>
        <div class="might-top">
            <p>Lorem Ipsum is simply typesetting industry.</p>
            <a href="single">Lorem Ipsum <i> </i></a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="might-grid">
        <div class="grid-might">
            <a href="single"><img src="/templates/reporter/images/mi2.jpg" class="img-responsive" alt=""> </a>
        </div>
        <div class="might-top">
            <p>Lorem Ipsum is simply typesetting industry.</p>
            <a href="single">Lorem Ipsum <i> </i></a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="might-grid">
        <div class="grid-might">
            <a href="single"><img src="/templates/reporter/images/mi3.jpg" class="img-responsive" alt=""> </a>
        </div>
        <div class="might-top">
            <p>Lorem Ipsum is simply typesetting industry.</p>
            <a href="single">Lorem Ipsum <i> </i></a>
        </div>
        <div class="clearfix"></div>
    </div>
</div>