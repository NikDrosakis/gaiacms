<div class="videos">
    <div class="video-grid">
        <div class="video">
            <a href="single"><i class="play"></i></a>
        </div>
        <div class="video-name">
            <a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="video-grid">
        <div class="video">
            <a href="single"><i class="play"></i></a>
        </div>
        <div class="video-name">
            <a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="video-grid">
        <div class="video">
            <a href="single"><i class="play"></i></a>
        </div>
        <div class="video-name">
            <a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="video-grid">
        <div class="video">
            <a href="single"><i class="play"></i></a>
        </div>
        <div class="video-name">
            <a href="single">Lorem ipsum dolor sit amet conse ctetur adipiscing elit</a>
        </div>
        <div class="clearfix"></div>
    </div>
    <a class="more1" href="single">More  +</a>
    <div class="clearfix"></div>
</div>