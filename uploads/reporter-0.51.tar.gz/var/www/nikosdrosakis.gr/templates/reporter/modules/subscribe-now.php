<div class="subscribe-now">
    <div class="discount">
        <a href="#">
            <div class="save">
                <p>Save</p>
                <p>upto</p>
            </div>
            <div class="percent">
                <h2>50%</h2>
            </div>
            <div class="clearfix"></div>
    </div>
    <h3 class="sn">subscribe     now</h3>
    </a>
</div>