<div class="classifieds">
    <h3>Free Classified Ads</h3>
    <div class="classified-grids">
        <a href="#">
            <div class="classified-grid">
                <h4>Real Estate</h4>
            </div>
        </a>
        <a href="#">
            <div class="classified-grid">
                <h4>Jobs</h4>
            </div>
        </a>
        <a href="#">
            <div class="classified-grid">
                <h4>Electronics</h4>
            </div>
        </a>
        <div class="clearfix"></div>
    </div>
    <div class="classified-grids">
        <a href="#">
            <div class="classified-grid">
                <h4>Automobiles</h4>
            </div>
        </a>
        <a href="#">
            <div class="classified-grid">
                <h4>Services</h4>
            </div>
        </a>
        <a href="#">
            <div class="classified-grid">
                <h4>Home Store</h4>
            </div>
        </a>
        <div class="clearfix"></div>
    </div>
    <div class="classified-grids">
        <a href="#">
            <div class="classified-grid">
                <h4>Education & Learning</h4>
            </div>
        </a>
        <a href="#">
            <div class="classified-grid">
                <h4>Travels</h4>
            </div>
        </a>
        <a href="#">
            <div class="classified-grid">
                <h4>Business Opportunities</h4>
            </div>
        </a>
        <div class="clearfix"></div>
    </div>
    <div class="classified-grids">
        <a href="#">
            <div class="classified-grid">
                <h4>Entertainment</h4>
            </div>
        </a>
        <a href="#">
            <div class="classified-grid">
                <h4>Matrimonial</h4>
            </div>
        </a>
        <div class="clearfix"></div>
    </div>
</div>