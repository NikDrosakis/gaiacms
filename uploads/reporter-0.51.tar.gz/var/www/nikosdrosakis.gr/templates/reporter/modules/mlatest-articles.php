<div class="mlatest-articles">
    <div class="main-title-head">
        <h3>latest    articles</h3>
        <a href="single">More  +</a>
        <div class="clearfix"></div>
    </div>
    <div class="world-news-grids">
        <div class="world-news-grid">
            <a href="single"><img src="/templates/reporter/images/ma1.jpg" alt="" /></a>
            <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="single">Read More</a>
        </div>
        <div class="world-news-grid">
            <a href="single"><img src="/templates/reporter/images/a2.jpg" alt="" /></a>
            <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="single">Read More</a>
        </div>
        <div class="world-news-grid">
            <a href="single"><img src="/templates/reporter/images/a3.jpg" alt="" /></a>
            <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="single">Read More</a>
        </div>
        <div class="clearfix"></div>
    </div>
</div>