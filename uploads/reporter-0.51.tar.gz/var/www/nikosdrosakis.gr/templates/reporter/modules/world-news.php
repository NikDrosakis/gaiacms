<div class="world-news">
    <div class="main-title-head">
        <h3>from   around   the   world</h3>
        <a href="single">More  +</a>
        <div class="clearfix"></div>
    </div>
    <div class="world-news-grids">
        <div class="world-news-grid">
            <a href="single"><img src="/templates/reporter/images/n1.jpg" alt="" /></a>
            <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="single">Read More</a>
        </div>
        <div class="world-news-grid">
            <a href="single"><img src="/templates/reporter/images/n2.jpg" alt="" /></a>
            <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="single">Read More</a>
        </div>
        <div class="world-news-grid">
            <a href="single"><img src="/templates/reporter/images/n3.jpg" alt="" /></a>
            <a href="#" class="title">Lorem ipsum dolor sit amet, consectetur </a>
            <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
            <a href="single">Read More</a>
        </div>
        <div class="clearfix"></div>
    </div>
</div>