<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
    <title><?=$this->is('title');?></title>
    <link rel="shortcut icon" type="image/x-icon" href="/gaia/img/logo.png">
    <script src="/gaia/js/libs.js"></script>
    <script type="text/javascript">
        var GS=<?php echo json_encode($this->GS, JSON_UNESCAPED_UNICODE);?>;
    </script>
    <script src="/gaia/js/gaia.js"></script>
    <!---<link href="/gaia/css/global.css" type="text/css" media="all">--->
    <!-- Custom Theme files -->
    <link href="/templates/reporter/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/templates/reporter/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Custom Theme files -->
    <script type="text/javascript" src="/templates/reporter/js/jquery.leanModal.min.js"></script>
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />
    <!-- Custom Theme files -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="The News Reporter Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!--webfont-->

</head>
<body>
<!-- header-section-starts -->
<div class="container">
    <div class="news-paper">
        <div class="header">
            <div class="header-left">
                <div class="logo">
                    <a href="index">
                        <h6>the</h6>
                        <h1><?=$this->page()->pvar('title');?></h1>
                    </a>
                </div>
            </div>
            <div class="social-icons">
                <li><a href="#"><i class="twitter"></i></a></li>
                <li><a href="#"><i class="facebook"></i></a></li>
                <li><a href="#"><i class="rss"></i></a></li>
                <li><div class="facebook"><div id="fb-root"></div>

                        <div id="fb-root"></div>
                    </div></li>
                <script>(function(d, s, id) {
                        var js, fjs = d.getElementsByTagName(s)[0];
                        if (d.getElementById(id)) return;
                        js = d.createElement(s); js.id = id;
                        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
                        fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));</script>

                <div class="fb-like" data-href="https://www.facebook.com/w3layouts" data-layout="button_count" data-action="like" data-show-faces="true" data-share="false"></div>


            </div>
            <div class="clearfix"></div>

            <div class="header-right">
                <div class="top-menu">
                    <ul>
                        <li><a href="/index">Home</a></li> |
                        <li><a href="/about">About Us</a></li> |
                        <li><a href="/contact">Contact Us</a></li>  |
                        <li><a id="modal_trigger" href="#modal" class="btn1">Login</a>

                            <div id="modal" class="popupContainer" style="display:none;">
                                <header class="popupHeader">
                                    <span class="header_title">Login</span>
                                    <span class="modal_close"><i class="fa fa-times"></i></span>
                                </header>

                                <section class="popupBody">
                                    <!-- Social Login -->
                                    <div class="social_login">
                                        <div class="">
                                            <a href="#" class="social_box fb">
                                                <span class="icon"><i class="fa fa-facebook"></i></span>
                                                <span class="icon_title">Connect with Facebook</span>

                                            </a>

                                            <a href="#" class="social_box google">
                                                <span class="icon"><i class="fa fa-google-plus"></i></span>
                                                <span class="icon_title">Connect with Google</span>
                                            </a>
                                        </div>

                                        <div class="centeredText">
                                            <span>Or use your Email address</span>
                                        </div>

                                        <div class="action_btns">
                                            <div class="one_half"><a href="#" id="login_form" class="btn">Login</a></div>
                                            <div class="one_half last"><a href="#" id="register_form" class="btn">Sign up</a></div>
                                        </div>
                                    </div>

                                    <!-- Username & Password Login form -->
                                    <div class="user_login">
                                        <form>
                                            <label>Email / Username</label>
                                            <input type="text" />
                                            <br />

                                            <label>Password</label>
                                            <input type="password" />
                                            <br />

                                            <div class="checkbox">
                                                <input id="remember" type="checkbox" />
                                                <label for="remember">Remember me on this computer</label>
                                            </div>

                                            <div class="action_btns">
                                                <div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> Back</a></div>
                                                <div class="one_half last"><a href="#" class="btn btn_red">Login</a></div>
                                            </div>
                                        </form>

                                        <a href="#" class="forgot_password">Forgot password?</a>
                                    </div>

                                    <!-- Register Form -->
                                    <div class="user_register">
                                        <form>
                                            <label>Full Name</label>
                                            <input type="text" />
                                            <br />

                                            <label>Email Address</label>
                                            <input type="email" />
                                            <br />

                                            <label>Password</label>
                                            <input type="password" />
                                            <br />

                                            <div class="checkbox">
                                                <input id="send_updates" type="checkbox" />
                                                <label for="send_updates">Send me occasional email updates</label>
                                            </div>

                                            <div class="action_btns">
                                                <div class="one_half"><a href="#" class="btn back_btn"><i class="fa fa-angle-double-left"></i> Back</a></div>
                                                <div class="one_half last"><a href="#" class="btn btn_red">Register</a></div>
                                            </div>
                                        </form>
                                    </div>
                                </section>
                            </div>

                            <script type="text/javascript">
                                $("#modal_trigger").leanModal({top : 200, overlay : 0.6, closeButton: ".modal_close" });

                                $(function(){
                                    // Calling Login Form
                                    $("#login_form").click(function(){
                                        $(".social_login").hide();
                                        $(".user_login").show();
                                        return false;
                                    });

                                    // Calling Register Form
                                    $("#register_form").click(function(){
                                        $(".social_login").hide();
                                        $(".user_register").show();
                                        $(".header_title").text('Register');
                                        return false;
                                    });

                                    // Going back to Social Forms
                                    $(".back_btn").click(function(){
                                        $(".user_login").hide();
                                        $(".user_register").hide();
                                        $(".social_login").show();
                                        $(".header_title").text('Login');
                                        return false;
                                    });

                                })
                            </script></li> |
                        <li><a class="play-icon popup-with-zoom-anim" href="#small-dialog1">Subscribe</a></li>
                    </ul>
                </div>
                <!---pop-up-box---->
                <link href="/templates/reporter/css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
                <script src="/templates/reporter/js/jquery.magnific-popup.js" type="text/javascript"></script>
                <!---//pop-up-box---->
                <div id="small-dialog1" class="mfp-hide">
                    <div class="signup">
                        <h3>Subscribe</h3>
                        <h4>Enter Your Valid E-mail</h4>
                        <input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" />
                        <div class="clearfix"></div>
                        <input type="submit"  value="Subscribe Now"/>
                    </div>
                </div>

                <script>
                    $(document).ready(function() {
                        $('.popup-with-zoom-anim').magnificPopup({
                            type: 'inline',
                            fixedContentPos: false,
                            fixedBgPos: true,
                            overflowY: 'auto',
                            closeBtnInside: true,
                            preloader: false,
                            midClick: true,
                            removalDelay: 300,
                            mainClass: 'my-mfp-zoom-in'
                        });

                    });
                </script>
                <div class="search">
                    <form>
                        <input type="text" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}"/>
                        <input type="submit" value="">
                    </form>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>

        <span class="menu"></span>
        <div class="menu-strip">
            <ul>
                <li><a href="/index">worldnews</a></li>
                <li><a href="/sports">sports</a></li>
                <li><a href="/tech">tech</a></li>
                <li><a href="/business">business</a></li>
                <li><a href="/movies">Movies</a></li>
                <li><a href="/movies">entertainment</a></li>
                <li><a href="/books">Books</a></li>
                <li><a href="/movies">culture</a></li>
                <li><a href="/classifieds">classifieds</a></li>
                <li><a href="/archive">Archive</a></li>
            </ul>
        </div>

        <!-- script for menu -->
        <script>
            $( "span.menu" ).click(function() {
                $( ".menu-strip" ).slideToggle( "slow", function() {
                    // Animation complete.
                });
            });
        </script>


        <!-- script for menu -->
        <div class="clearfix"></div>

