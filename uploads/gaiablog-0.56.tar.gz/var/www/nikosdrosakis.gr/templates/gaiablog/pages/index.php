
		<!-- Home -->
			<div class="wrapper style1 first">
				<article class="container" id="top">
					<div class="row">
						<div class="4u">
							<span class="image fit"><img src="/templates/gaiablog/images/pic00.jpg" alt="" /></span>
						</div>
						<div class="8u">
							<header>
								<h1 id="h1_1"><?=$this->page()->pvar('h1_1');?><!--APPEND h1_1---></strong></h1>
							</header>
							<p id="p_1"><?=$this->page()->pvar('p_1');?><!--APPEND p_1---></p>
							<a href="#work" class="button big scrolly" id="a_1"><?=$this->page()->pvar('a_1');?></a>
						</div>
					</div>
				</article>
			</div>

		<!-- Work -->
			<div class="wrapper style2">
				<article id="work">
					<header>
						<h2 id="h2_1"><?=$this->page()->pvar('h2_1');?></h2>
						<p id="p_2"><?=$this->page()->pvar('p_2');?></p>
					</header>
					<div class="container">
						<div class="row">
							<div class="4u">
								<section class="box style1">
									<span class="icon featured fa-comments-o"></span>
									<h3 id="h3_1"><?=$this->page()->pvar('h3_1');?></h3>
									<p id="p_3"><?=$this->page()->pvar('p_3');?></p>
								</section>
							</div>
							<div class="4u">
								<section class="box style1">
									<span class="icon featured fa-camera-retro"></span>
									<h3><?=$this->page()->pvar('h3_2');?></h3>
									<p id="p_4"><?=$this->page()->pvar('p_4');?></p>
								</section>
							</div>
							<div class="4u">
								<section class="box style1">
									<span class="icon featured fa-thumbs-o-up"></span>
									<h3><?=$this->page()->pvar('h3_3');?></h3>
									<p id="p_5"><?=$this->page()->pvar('p_5');?></p>
								</section>
							</div>
						</div>
					</div>
					<footer>
						<p id="p_6"><?=$this->page()->pvar('p_6');?></p>
						<a href="#portfolio" class="button big scrolly"><?=$this->page()->pvar('a_2');?></a>
					</footer>
				</article>
			</div>

		<!-- Portfolio -->
			<div class="wrapper style3">
				<article id="portfolio">
					<header>
						<h2><?=$this->page()->pvar('h2_2');?></h2>
						<p><?=$this->page()->pvar('p_7');?></p>
					</header>
					<div class="container">
						<div class="row">
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="/templates/gaiablog/<?=$this->page()->pvar('img_1');?>" alt="<?=$this->page()->pvar('img_1');?>" /></a>
									<h3><a href="#"><?=$this->page()->pvar('a_3');?></a></h3>
									<p><?=$this->page()->pvar('p_8');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="/templates/gaiablog/<?=$this->page()->pvar('img_2');?>" alt="<?=$this->page()->pvar('img_2');?>" /></a>
									<h3><a href="#"><?=$this->page()->pvar('a_4');?></a></h3>
									<p><?=$this->page()->pvar('p_9');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="/templates/gaiablog/<?=$this->page()->pvar('img_3');?>" alt="<?=$this->page()->pvar('img_3');?>" /></a>
									<h3><a href="#"><?=$this->page()->pvar('a_5');?></a></h3>
									<p><?=$this->page()->pvar('p_10');?></p>
								</article>
							</div>
						</div>
						<div class="row">
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="/templates/gaiablog/<?=$this->page()->pvar('img_4');?>" alt="" /></a>
									<h3><a href="#"><?=$this->page()->pvar('a_6');?></a></h3>
									<p><?=$this->page()->pvar('p_11');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="/templates/gaiablog/<?=$this->page()->pvar('img_5');?>" alt="" /></a>
									<h3><a href="#"><?=$this->page()->pvar('a_7');?></a></h3>
									<p><?=$this->page()->pvar('p_12');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="/templates/gaiablog/<?=$this->page()->pvar('img_6');?>" alt="" /></a>
									<h3><a href="#"><?=$this->page()->pvar('a_8');?></a></h3>
									<p><?=$this->page()->pvar('p_13');?></p>
								</article>
							</div>
						</div>
					</div>
					<footer>
						<p><?=$this->page()->pvar('p_14');?></p>
						<a href="#contact" class="button big scrolly"><?=$this->page()->pvar('a_9');?></a>
					</footer>
				</article>
			</div>

