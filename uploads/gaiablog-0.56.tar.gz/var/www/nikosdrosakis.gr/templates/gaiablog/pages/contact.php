<!-- Contact -->
<div class="wrapper style4">
    <article id="contact" class="container small">
        <header>
            <h2><?=$cms->dic('h2_3');?></h2>
            <p><?=$cms->dic('p_15');?></p>
        </header>
        <div>
            <div class="row">
                <div class="12u">
                    <form method="post" action="#">
                        <div>
                            <div class="row">
                                <div class="6u">
                                    <input type="text" name="name" id="name" placeholder="Name" />
                                </div>
                                <div class="6u">
                                    <input type="text" name="email" id="email" placeholder="Email" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="12u">
                                    <input type="text" name="subject" id="subject" placeholder="Subject" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="12u">
                                    <textarea name="message" id="message" placeholder="Message"></textarea>
                                </div>
                            </div>
                            <div class="row double">
                                <div class="12u">
                                    <ul class="actions">
                                        <li><input type="submit" value="Send Message" /></li>
                                        <li><input type="reset" value="Clear Form" class="alt" /></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="12u">
                    <hr />
                    <h3>Find me on ...</h3>
                    <div id="social">
                        <!----------------APPENDED MODULE SOCIAL----------------------->
                    </div>
                    <hr />
                </div>
            </div>
        </div>
        <footer>
            <ul id="copyright">
                <li><?=$cms->is('copyright');?></li>
            </ul>
        </footer>
    </article>
</div>

