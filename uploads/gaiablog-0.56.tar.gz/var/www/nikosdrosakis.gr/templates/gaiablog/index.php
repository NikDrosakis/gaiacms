<!DOCTYPE HTML>
<!--
	Miniport by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
	
	<title><?=$cms->dic('title');?></title>

<!---------APPEND SEO METATAGS------------>

		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<!---<script src="/gaia/js/init.js"></script>--->
		<script src="<?=TEMPLATE_URL?>js/jquery.min.js"></script>
		<script src="<?=TEMPLATE_URL?>js/jquery.scrolly.min.js"></script>
		<script src="<?=TEMPLATE_URL?>js/skel.min.js"></script>
		<script src="<?=TEMPLATE_URL?>js/init.js"></script>
		
		<noscript>
			
			<link rel="stylesheet" href="<?=TEMPLATE_URL?>css/skel.css" />
			<link rel="stylesheet" href="<?=TEMPLATE_URL?>css/style.css" />
			<link rel="stylesheet" href="<?=TEMPLATE_URL?>css/style-desktop.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
	<link rel="stylesheet" href="/gaia/css/global.css" />
  <script src="/gaia/js/libs.js"></script>
  
  
  <!---------APPEND HEAD JS + CSS FILES------------>
  </head>
	<body><script type="text/javascript">var GLOBAL=<?php echo json_encode($GLOBAL, JSON_UNESCAPED_UNICODE);?>;</script>
	<script src="/gaia/js/init.js"></script>


		<!-- Nav -->
			<nav id="menutop"><!---------APPENDED MENU----------></nav>

			
<div>
<h2>Choose Style</h2>
<?php $style_list= $cms->sys()->fetchList(array('style','status'),'menu');?>
<select id="chooseStyle">
<option value=0>Select</option>
<?php foreach($style_list as $styl => $status){ ?>
<option value="<?=$styl?>" <?=$status==1?'selected="selected"':''?> ><?=$styl?></option>
<?php } ?>
</select>
</div>

		<!-- Home -->
			<div class="wrapper style1 first">
				<article class="container" id="top">
					<div class="row">
						<div class="4u">
							<span class="image fit"><img src="<?=TEMPLATE_URL?>images/pic00.jpg" alt="" /></span>
						</div>
						<div class="8u">
							<header>
								<h1 id="h1_1"><?=$cms->dic('h1_1');?><!--APPEND h1_1---></strong></h1>
							</header>
							<p id="p_1"><?=$cms->dic('p_1');?><!--APPEND p_1---></p>
							<a href="#work" class="button big scrolly" id="a_1"><?=$cms->dic('a_1');?></a>
						</div>
					</div>
				</article>
			</div>

		<!-- Work -->
			<div class="wrapper style2">
				<article id="work">
					<header>
						<h2 id="h2_1"><?=$cms->dic('h2_1');?></h2>
						<p id="p_2"><?=$cms->dic('p_2');?></p>
					</header>
					<div class="container">
						<div class="row">
							<div class="4u">
								<section class="box style1">
									<span class="icon featured fa-comments-o"></span>
									<h3 id="h3_1"><?=$cms->dic('h3_1');?></h3>
									<p id="p_3"><?=$cms->dic('p_3');?></p>
								</section>
							</div>
							<div class="4u">
								<section class="box style1">
									<span class="icon featured fa-camera-retro"></span>
									<h3><?=$cms->dic('h3_2');?></h3>
									<p id="p_4"><?=$cms->dic('p_4');?></p>
								</section>
							</div>
							<div class="4u">
								<section class="box style1">
									<span class="icon featured fa-thumbs-o-up"></span>
									<h3><?=$cms->dic('h3_3');?></h3>
									<p id="p_5"><?=$cms->dic('p_5');?></p>
								</section>
							</div>
						</div>
					</div>
					<footer>
						<p id="p_6"><?=$cms->dic('p_6');?></p>
						<a href="#portfolio" class="button big scrolly"><?=$cms->dic('a_2');?></a>
					</footer>
				</article>
			</div>

		<!-- Portfolio -->
			<div class="wrapper style3">
				<article id="portfolio">
					<header>
						<h2><?=$cms->dic('h2_2');?></h2>
						<p><?=$cms->dic('p_7');?></p>
					</header>
					<div class="container">
						<div class="row">
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="<?=TEMPLATE_URL?><?=$cms->dic('img_1');?>" alt="<?=$cms->dic('img_1');?>" /></a>
									<h3><a href="#"><?=$cms->dic('a_3');?></a></h3>
									<p><?=$cms->dic('p_8');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="<?=TEMPLATE_URL?><?=$cms->dic('img_2');?>" alt="<?=$cms->dic('img_2');?>" /></a>
									<h3><a href="#"><?=$cms->dic('a_4');?></a></h3>
									<p><?=$cms->dic('p_9');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="<?=TEMPLATE_URL?><?=$cms->dic('img_3');?>" alt="<?=$cms->dic('img_3');?>" /></a>
									<h3><a href="#"><?=$cms->dic('a_5');?></a></h3>
									<p><?=$cms->dic('p_10');?></p>
								</article>
							</div>
						</div>
						<div class="row">
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="<?=TEMPLATE_URL?><?=$cms->dic('img_4');?>" alt="" /></a>
									<h3><a href="#"><?=$cms->dic('a_6');?></a></h3>
									<p><?=$cms->dic('p_11');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="<?=TEMPLATE_URL?><?=$cms->dic('img_5');?>" alt="" /></a>
									<h3><a href="#"><?=$cms->dic('a_7');?></a></h3>
									<p><?=$cms->dic('p_12');?></p>
								</article>
							</div>
							<div class="4u">
								<article class="box style2">
									<a href="#" class="image featured"><img src="<?=TEMPLATE_URL?><?=$cms->dic('img_6');?>" alt="" /></a>
									<h3><a href="#"><?=$cms->dic('a_8');?></a></h3>
									<p><?=$cms->dic('p_13');?></p>
								</article>
							</div>
						</div>
					</div>
					<footer>
						<p><?=$cms->dic('p_14');?></p>
						<a href="#contact" class="button big scrolly"><?=$cms->dic('a_9');?></a>
					</footer>
				</article>
			</div>

		<!-- Contact -->
			<div class="wrapper style4">
				<article id="contact" class="container small">
					<header>
						<h2><?=$cms->dic('h2_3');?></h2>
						<p><?=$cms->dic('p_15');?></p>
					</header>
					<div>
						<div class="row">
							<div class="12u">
								<form method="post" action="#">
									<div>
										<div class="row">
											<div class="6u">
												<input type="text" name="name" id="name" placeholder="Name" />
											</div>
											<div class="6u">
												<input type="text" name="email" id="email" placeholder="Email" />
											</div>
										</div>
										<div class="row">
											<div class="12u">
												<input type="text" name="subject" id="subject" placeholder="Subject" />
											</div>
										</div>
										<div class="row">
											<div class="12u">
												<textarea name="message" id="message" placeholder="Message"></textarea>
											</div>
										</div>
										<div class="row double">
											<div class="12u">
												<ul class="actions">
													<li><input type="submit" value="Send Message" /></li>
													<li><input type="reset" value="Clear Form" class="alt" /></li>
												</ul>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
						<div class="row">
							<div class="12u">
								<hr />
								<h3>Find me on ...</h3>
						<div id="social">
						<!----------------APPENDED MODULE SOCIAL----------------------->
						</div>
								<hr />
							</div>
						</div>
					</div>
					<footer>
						<ul id="copyright">
							<li><?=$cms->is('copyright');?></li>
						</ul>
					</footer>
				</article>
			</div>

	</body>
		<div id="include_modules">
		<script src="/modules/menu/menu.js"></script>
		<script src="/modules/social/social.js"></script>
		</div>
		<!-----------APPENDED MODULES--------->
		
	</html>
