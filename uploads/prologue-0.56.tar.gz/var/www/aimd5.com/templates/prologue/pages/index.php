<!-- Contact -->
<div id="wa-1" style="width:14%;min-height:800px;display:inline;float:right;background: #000;">

    <h4>widgetized area 1</h4>
</div>


<div id="main">
    <!-- Intro -->
    <section id="top" class="one dark cover">
        <div class="container">

            <header>
                <h2 class="alt"><?=$this->page()->pvar('h2_0');?></h2>
                <p><?=$this->page()->pvar('p_2');?></p>
            </header>

            <footer>
                <a href="#portfolio" class="button scrolly"><?=$this->page()->pvar('a_1');?></a>
            </footer>

        </div>
    </section>


    <!-- Portfolio -->
    <section id="portfolio" class="two">
        <div class="container">

            <header>
                <h2><?=$this->page()->pvar('h2_1');?></h2>
            </header>

            <p><?=$this->page()->pvar('p_3');?></p>

            <div class="row">

                <div class="4u">
                    <article class="item">
                        <a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_1');?>" alt="" /></a>
                        <header>
                            <h3><?=$this->page()->pvar('img_1_title');?></h3>
                        </header>
                    </article>
                    <article class="item">
                        <a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_2');?>" alt="" /></a>
                        <header>
                            <h3><?=$this->page()->pvar('img_2_title');?></h3>
                        </header>
                    </article>
                </div>

                <div class="4u">
                    <article class="item">
                        <a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_3');?>" alt="" /></a>
                        <header>
                            <h3><?=$this->page()->pvar('img_3_title');?></h3>
                        </header>
                    </article>
                    <article class="item">
                        <a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_4');?>" alt="" /></a>
                        <header>
                            <h3><?=$this->page()->pvar('img_4_title');?></h3>
                        </header>
                    </article>
                </div>

                <div class="4u">
                    <article class="item">
                        <a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_5');?>" alt="" /></a>
                        <header>
                            <h3><?=$this->page()->pvar('img_5_title');?></h3>
                        </header>
                    </article>
                    <article class="item">
                        <a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_6');?>" alt="" /></a>
                        <header>
                            <h3><?=$this->page()->pvar('img_6_title');?></h3>
                        </header>
                    </article>
                </div>
            </div>

        </div>
    </section>


</div>

