<!-- About Me -->
<section id="about" class="three">
    <div class="container">

        <header>
            <h2><?=$this->page()->pvar('h2_2');?></h2>
        </header>

        <a href="#" class="image featured"><img src="<?=$this->page()->pvar('img_8');?>" alt="" /></a>

        <p><?=$this->page()->pvar('img_8_title');?></p>

    </div>
</section>