<!-- Contact -->
<div id="main">
<section id="contact" class="four">
    <div class="container">

        <header>
            <h2><?=$this->page()->pvar('h2_3');?></h2>
        </header>

        <p><?=$this->page()->pvar('p_4');?></p>

        <form method="post" action="#">
            <div class="row half">
                <div class="6u"><input id="mailer_name" type="text" name="name" placeholder="Name" /></div>
                <div class="6u"><input id="mailer_email" type="text" name="email" placeholder="Email" /></div>
            </div>
            <div class="row half">
                <div class="12u">
                    <textarea id="mailer_message" name="message" placeholder="Message"></textarea>
                </div>
            </div>
            <div class="row">
                <div class="12u">
                    <input id="mailer_submit" type="submit" value="Send Message" />
                </div>
            </div>
        </form>

    </div>
</section>
</div>
