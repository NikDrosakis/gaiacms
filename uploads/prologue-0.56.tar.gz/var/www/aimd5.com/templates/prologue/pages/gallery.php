					
				<!-- Portfolio -->
					<section id="portfolio" class="two">
						<div class="container">
					
							<header>
								<h2><?=$this->page()->pvar('h2_1');?></h2>
							</header>
							
							<p><?=$this->page()->pvar('p_3');?></p>
						
							<div class="row">
							
								<div class="4u">
									<article class="item">
										<a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_1');?>" alt="" /></a>
										<header>
											<h3><?=$this->page()->pvar('img_1_title');?></h3>
										</header>
									</article>
									<article class="item">
										<a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_2');?>" alt="" /></a>
										<header>
											<h3><?=$this->page()->pvar('img_2_title');?></h3>
										</header>
									</article>
								</div>
								
								<div class="4u">
									<article class="item">
										<a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_3');?>" alt="" /></a>
										<header>
											<h3><?=$this->page()->pvar('img_3_title');?></h3>
										</header>
									</article>
									<article class="item">
										<a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_4');?>" alt="" /></a>
										<header>
											<h3><?=$this->page()->pvar('img_4_title');?></h3>
										</header>
									</article>
								</div>
								
								<div class="4u">
									<article class="item">
										<a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_5');?>" alt="" /></a>
										<header>
											<h3><?=$this->page()->pvar('img_5_title');?></h3>
										</header>
									</article>
									<article class="item">
										<a href="#" class="image fit"><img src="<?=$this->page()->pvar('img_6');?>" alt="" /></a>
										<header>
											<h3><?=$this->page()->pvar('img_6_title');?></h3>
										</header>
									</article>
								</div>
							</div>

						</div>
					</section>