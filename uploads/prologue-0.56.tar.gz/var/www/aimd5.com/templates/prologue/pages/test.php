<?php
if(!ob_start("ob_gzhandler")) ob_start();

//START THE SESSION
if(!isset($_SESSION))session_start();

include (dirname(__FILE__)."/config.php");
include (dirname(__FILE__)."/generic.php");
include (dirname(__FILE__)."/glob.php");
include (dirname(dirname(dirname(__FILE__)))."/login/login.php");

spl_autoload_register(function ($className) {
    if(file_exists(dirname(__FILE__)."/class/".$className.".php"))
        include (dirname(__FILE__)."/class/".$className.".php");
});

//START CMS
//$cms=new Gaia;

//start the template
//if(CUR_DIR!='ajax' && explode('.',basename(__FILE__))[1]!='ajax') {
  //  $cms->start_page();
//}

echo Gaia::lang();

print_r($_SESSION);
print_r($_COOKIE);
