<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
	
	// replace  js/  TEMPLATE_URL css/
	// replace css/  TEMPLATE_URL css/
	// replace image/  TEMPLATE_URL TEMPLATE_URL image/
-->
<html>
	<head>
		<title><?=$cms->dic('title');?></title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		 <script src="/gaia/js/libs.js"></script>
		<!--[if lte IE 8]><script src="/templates/prologue/css/ie/html5shiv.js"></script><![endif]-->
		<script src="/templates/prologue/js/jquery.scrolly.min.js"></script>
		<script src="/templates/prologue/js/jquery.scrollzer.min.js"></script>
		<script src="/templates/prologue/js/skel.min.js"></script>
		<script src="/templates/prologue/js/skel-layers.min.js"></script>
		<script src="/templates/prologue/js/init.js"></script>
		
			<link href="/gaia/css/global.css" rel="stylesheet" type="text/css" />
		<noscript>
			<link rel="stylesheet" href="/templates/prologue/css/skel.css" />
			<link rel="stylesheet" href="/templates/prologue/css/style.css" />
			<link rel="stylesheet" href="/templates/prologue/css/style-wide.css" />
		</noscript>
		<!--[if lte IE 9]><link rel="stylesheet" href="/templates/prologue/css/ie/v9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="/templates/prologue/css/ie/v8.css" /><![endif]-->

 </head>

	<body>
<script type="text/javascript">
var GLOBAL=<?php echo json_encode($GLOBAL, JSON_UNESCAPED_UNICODE);?>;
</script>
  <script src="/gaia/js/init.js"></script>
		<!-- Header -->
			<div id="header" class="skel-layers-fixed">

				<div class="top">

					<!-- Logo -->
						<div id="logo">
							<span class="image avatar48"><img src="<?=$cms->dic('img_0');?>" alt="" /></span>
							<h1 id="title"><?=$cms->dic('h1_1');?></h1>
							<p><?=$cms->dic('p_1');?></p>
						</div>

					<!-- Nav -->
						<nav id="nav">
						<ul>
							<?php for($i=0;$i<count($GLOBAL['menu']);$i++){ ?>
								<li><a href="<?=$GLOBAL['menu'][$i]['link']?>" id="top-link" class="skel-layers-ignoreHref"><span class="icon fa-home"><?=$GLOBAL['menu'][$i]['alias']?></span></a></li>
							<?php } ?>
							</ul>
						</nav>
						
				</div>
				
				<div class="bottom">

					<!-- Social Icons -->
						<ul class="icons">
							<li><a href="<?=$cms->is('twitter');?>" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="<?=$cms->is('facebook');?>" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="<?=$cms->is('github');?>" class="icon fa-github"><span class="label">Github</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
						</ul>
				
				</div>
			
			</div>

		<!-- Main -->
			<div id="main">

				<!-- Intro -->
					<section id="top" class="one dark cover">
						<div class="container">

							<header>
								<h2 class="alt"><?=$cms->dic('h2_0');?></h2>
								<p><?=$cms->dic('p_2');?></p>
							</header>
							
							<footer>
								<a href="#portfolio" class="button scrolly"><?=$cms->dic('a_1');?></a>
							</footer>

						</div>
					</section>

		<?php $cms->module('gallery'); ?>
		
		<?php $cms->module('aboutme'); ?>

		<?php $cms->module('contact'); ?>
			
			</div>
	<?php include 'footer.php'; ?>

	</body>
</html>