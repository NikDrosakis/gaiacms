			<div id="footer">

					<ul class="copyright">
						<li><?=html_entity_decode ($this->is('copyright'));?></li>
					</ul>
				
			</div>