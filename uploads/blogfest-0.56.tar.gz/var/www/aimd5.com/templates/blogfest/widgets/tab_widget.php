<div class="tab_widget">

    <ul class="tabs">
        <li class="active"><em title="tab1">Popular  posts</em></li>
        <li><em title="tab2">recent  posts</em></li>
        <li><em title="tab3">Comments</em></li>
    </ul>

    <div class="tab_container">

        <div id="tab1" class="tab_content">

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Curabitur dictum magna mi iaculis bibendum</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">5 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Donec eros augue, tristique in feugiat ut pellentes</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Curagitur</a> |  <a href="#" title="Comments">0 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Nullam sit amet ipsum non diam eleifend rhoncus</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Inspirational</a> |  <a href="#" title="Comments">21 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Quisque fringilla risus nec libero consectetur</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">32 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Quisque fringilla risus nec libero consectetur</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">32 comments</a> </p>

                </div>

            </div>

        </div><!-- #tab1 -->

        <div id="tab2" class="tab_content">

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Mauris mollis justo in ipsum aliquet molestie</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">22 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">In bibendum, nibh a gravida porta sapien neque</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Curagitur</a> |  <a href="#" title="Comments">54 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Curabitur vestibulum lectus sed augue sollicit</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Inspirational</a> |  <a href="#" title="Comments">2 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Vivamus adipiscing sollicitudin lectus</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">125 comments</a> </p>

                </div>

            </div>

            <div class="tab_article_preview">

                <div class="tab_article_preview_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_article_preview_content">

                    <h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Aenean felis arcu, suscipit vitae pulvinar</a></h3>
                    <p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">10 comments</a> </p>

                </div>

            </div>

        </div><!-- #tab2 -->

        <div id="tab3" class="tab_content">

            <div class="tab_last_comments">

                <div class="tab_last_comments_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_last_comments_content">

                    <p><span class="author"><a href="#" title="">John Doe</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
                    <p class="italic"><a href="#" title="">Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor ...</a></p>

                </div>

            </div>

            <div class="tab_last_comments">

                <div class="tab_last_comments_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_last_comments_content">

                    <p><span class="author"><a href="#" title="">Karl Voch</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
                    <p class="italic"><a href="#" title=""> Quisque fringilla risus nec libero consectetur at laoreet felis varius. Vivamus adipiscing sollicitudin lectus vitae sit amet ...</a></p>

                </div>

            </div>

            <div class="tab_last_comments">

                <div class="tab_last_comments_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_last_comments_content">

                    <p><span class="author"><a href="#" title="">Vivian Li</a></span> commented on <a href="#">Inspirational</a> - Jun 24, 2012</p>
                    <p class="italic"><a href="#" title="">Phasellus at eros eget felis fringilla ultrices. Morbi pellentesque mattis leo in molestie ...</a></p>

                </div>

            </div>

            <div class="tab_last_comments">

                <div class="tab_last_comments_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_last_comments_content">

                    <p><span class="author"><a href="#" title="">Francis Flaubert</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
                    <p class="italic"><a href="#" title="">Vivamus vestibulum enim sit amet dolor rhoncus sodales. Aenean ut odio mauris eget felis  ...</a></p>

                </div>

            </div>

            <div class="tab_last_comments">

                <div class="tab_last_comments_th"><a href="#" title=""><img src="/templates/blogfest/images/50x50.gif" alt="Lorem ipsum" /></a></div>

                <div class="tab_last_comments_content">

                    <p><span class="author"><a href="#" title="">Gotze Mallermung</a></span> commented on <a href="#">Curagitur</a> - <span class="meta">Jun 24, 2012</span></p>
                    <p class="italic"><a href="#" title="">Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor ...</a></p>

                </div>

            </div>

        </div><!-- #tab3 -->


    </div> <!-- .tab_container -->

</div>