	<div class="search">
				
	<form action="#" method="get" accept-charset="utf-8">
	<fieldset>
	<p><label for="s">enter your keyword...</label>
	<input type="text" class="searchbox" name="s" id="s" value="" />
	<input type="submit" class="searchbox_submit" value="" />
	</p></fieldset>
	</form>
				
	</div>