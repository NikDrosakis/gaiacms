<div class="post_listing_container">

<?php
$arch= $this->page()->archive($this->GS['page']);
for($i=0; $i<count($arch); $i++){
?>
	<div class="post_listing_preview">

	<div class="post_listing_image" style="width:98%;height:240px;overflow: hidden; display: block; margin:0 auto">

		<a href="#" title="lorem">
			<img src="<?=!empty($arch[$i]['img']) ? UPLOADS.$arch[$i]['img'] :'/templates/blogfest/images/345x240.gif'?>" alt=""
				 style="width: 100%;height: auto;margin: 0 auto;"/>
		</a></div>
				
	<div class="post_listing">
					
	<h1><?=$arch[$i]['title']?></h1>
	<p class="meta">Δημοσιεύτηκε στις <?=date('m ',$arch[$i]['published']).$this->GS['greekMonths'][intval(date('m'))-1].date(' Y',$arch[$i]['published'])?>
	<!---	| <a href="#" title="lorem">10 comments</a>--->
	</p>
	<p><?=$arch[$i]['excerpt']?></p>
						
	<p><a href="/<?=$arch[$i]['uri']?>" class="read_more">Περισσότερα</a></p>
					
	</div>
					
	</div>
<?php } ?>

</div>
