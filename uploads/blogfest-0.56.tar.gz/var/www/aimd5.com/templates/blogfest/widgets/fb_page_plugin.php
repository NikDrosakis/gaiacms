<div style="margin:15px">

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/el_GR/sdk.js#xfbml=1&version=v2.8&appId=433604016702204";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-page" data-href="https://www.facebook.com/venceremos.press/" data-tabs="timeline" data-width="440px" data-height="200px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/venceremos.press/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/venceremos.press/">Venceremos.press</a></blockquote></div>

</div>