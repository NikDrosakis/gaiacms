<div class="article_widget portfolio portfolio_widget">
			
				<div class="article_widget_preview">
				
					<a href="#" title="" ><img src="/templates/blogfest/images/200x125.gif" alt="lorem ipsum" /></a>
					
					<h1><a href="#" title="faucibus turpis eget i perdiet esci">faucibus turpis eget i perdiet esci</a></h1>
					
					<p>
						Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien. Curabitur dictum magna mi, iaculis bibendum tortor. 
						Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue.
					</p>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Aliquam bibendum consequat vene">Aliquam bibendum ed consequat vene</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Sed et hendrerit aenon dolor">Sed et hendrerit ut aenon dolor...</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Curabitur dictum magna mi">Curabitur eros et dictum magna mi</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Pellentesque vel sem id libero mollis">Pellentesque vel sem id libero mollis</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
			</div>
			
			<div class="article_widget portfolio portfolio_widget">
			
				<div class="article_widget_preview">
				
					<a href="#" title="" ><img src="/templates/blogfest/images/200x125.gif" alt="lorem ipsum" /></a>
					
					<h1><a href="#" title="faucibus turpis eget i perdiet esci">faucibus turpis eget i perdiet esci</a></h1>
					
					<p>
						Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien. Curabitur dictum magna mi, iaculis bibendum tortor. 
						Suspendisse potenti. Aenean felis arcu, suscipit vitae pulvinar interdum, dictum at augue.
					</p>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Aliquam bibendum consequat vene">Aliquam bibendum ed consequat vene</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Sed et hendrerit aenon dolor">Sed et hendrerit ut aenon dolor...</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Curabitur dictum magna mi">Curabitur eros et dictum magna mi</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="/templates/blogfest/images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Pellentesque vel sem id libero mollis">Pellentesque vel sem id libero mollis</a></h3>
						<p class="meta"><a href="#">read more</a></p>
						
					</div>
				
				</div>
			
			</div>