<div class="tier">
		
				<div class="tier_block">
				
					<h2>Faucibus</h2>
					<p class="tier_icon"><a href="#" title="Article"><img src="/templates/blogfest/images/article_icon.jpg" alt="Article" /></a></p>
					<p class="tier_excerpt">Dolor sit amet, consectetur adipiscing elit. Aenea purus orci, iaculis sit amet rutrum in, dictum vel odio. </p>
				
				</div>
			
				<div class="tier_block">
				
					<h2>consectetur </h2>
					<p class="tier_icon"><a href="#" title="Options"><img src="/templates/blogfest/images/options_icon.jpg" alt="Theme Options" /></a></p>
					<p class="tier_excerpt">Dolor sit amet, consectetur adipiscing elit. Aenea purus orci, iaculis sit amet rutrum in, dictum vel odio. </p>
				
				</div>
			
				<div class="tier_block">
				
					<h2>Egetiper </h2>
					<p class="tier_icon"><a href="#" title="Advertising"><img src="/templates/blogfest/images/advertising_icon.jpg" alt="Advertising module" /></a></p>
					<p class="tier_excerpt">Dolor sit amet, consectetur adipiscing elit. Aenea purus orci, iaculis sit amet rutrum in, dictum vel odio. </p>
				
				</div>
				
			</div>
			
			<!-- MAIN CONTENT start here 
			================================================== -->