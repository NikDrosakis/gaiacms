<?php $tags=$this->page()->tags($this->GS['page']); ?>
<div class="tags">

    <ul class="tags">

<?php if(!empty($tags)){foreach($tags as $tagname){ ?>
        <li><a href=""><?=$tagname?></a></li>
<?php }} ?>

    </ul>

</div>