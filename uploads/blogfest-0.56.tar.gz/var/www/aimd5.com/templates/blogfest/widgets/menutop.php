<?php
$page= $this->sys()->fetchAll("SELECT * FROM page WHERE menuid=12 ORDER BY sort");
?>
<div id="dd" class="menu wrapper-dropdown"><span class="responsive_label">Select a page</span>

                <ul id="menu-mobile" class="dropdown">
                    <?php for($i=0;$i<count($page);$i++){ ?>
                    <li><a href="<?=$page[$i]['link']?>" style="<?=$page[$i]['link']=='/'.$this->GS['page'] ? 'background:rgba(0, 100, 0, 0.1)':''?>" title="<?=$page[$i]['alias']?>"><?=$page[$i]['alias']?></a>
                    </li>
                    <?php } ?>

                </ul>

            </div>