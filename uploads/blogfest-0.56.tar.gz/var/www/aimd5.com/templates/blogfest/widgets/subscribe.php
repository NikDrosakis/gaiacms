<div class="subscribe" style="margin: 21px 0 0 0;">
					
<form action="#" method="get" accept-charset="utf-8">
							<fieldset>
<p>
	<label for="s">Email</label>
<input type="text" id="gs-subscribe-mail" class="subscribebox" placeholder="subscribe with your email" name="s" id="s"/>

	<label for="gs-register-submit">Submit</label>
<input type="button"  id="gs-register-submit" onclick="g.subscribe(g._('#gs-subscribe-mail').value)" class="subscribebox_submit" /></p>
			</fieldset>
		</form>
					
</div>