<div class="su-table su-table-style-1">
					
						<table class="custom-table">
						
							<thead>
							
								<tr>
									<th>Basic Plan</th>
									<th>Standard Plan</th>
									<th>Featured Plan</th>
									<th>Delux Plan</th>
								</tr>
								
							</thead>
							
							<tbody>
							
								<tr>
									<td>1000Mb Monthly traffic</td>
									<td>5000Mb Monthly traffic</td>
									<td>1000Mb Monthly traffic</td>
									<td>50000Mb Monthly traffic</td>
								</tr>
								<tr>
									<td>10Gb Disk space</td>
									<td>50Gb Disk space</td>
									<td>100Gb Disk space</td>
									<td>150Gb Disk space</td>
								</tr>
								<tr>
									<td>5 Domains</td>
									<td>10 Domains</td>
									<td>25 Domains</td>
									<td>50 Domains</td>
								</tr>
								<tr>
									<td>5 Subdomains</td>
									<td>10 Subdomains</td>
									<td>35 Subdomains</td>
									<td>Unlimited subdomains</td>
								</tr>
								<tr>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
								</tr>
								<tr>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
								</tr>
								<tr>
									<td>MySql Support</td>
									<td>MySql Support</td>
									<td>MySql Support</td>
									<td>MySql Support</td>
								</tr>
								<tr>
									<td><span class="button">Sign up</span></td>
									<td><span class="button">Sign up</span></td>
									<td><span class="button">Sign up</span></td>
									<td><span class="button">Sign up</span></td>
								</tr>
								
							</tbody>
							
							<tfoot>
							
								<tr>
									<td colspan="4">*Table Footer here…</td>
								</tr>
								
							</tfoot>
							
						</table>
					
					</div>
					
					<div class="su-table su-table-style-2">
					
						<table class="custom-table">
						
							<thead>
							
								<tr>
									<th>Basic Plan</th>
									<th>Standard Plan</th>
									<th>Featured Plan</th>
									<th>Delux Plan</th>
								</tr>
								
							</thead>
							
							<tbody>
							
								<tr>
									<td>1000Mb Monthly traffic</td>
									<td>5000Mb Monthly traffic</td>
									<td>1000Mb Monthly traffic</td>
									<td>50000Mb Monthly traffic</td>
								</tr>
								<tr>
									<td>10Gb Disk space</td>
									<td>50Gb Disk space</td>
									<td>100Gb Disk space</td>
									<td>150Gb Disk space</td>
								</tr>
								<tr>
									<td>5 Domains</td>
									<td>10 Domains</td>
									<td>25 Domains</td>
									<td>50 Domains</td>
								</tr>
								<tr>
									<td>5 Subdomains</td>
									<td>10 Subdomains</td>
									<td>35 Subdomains</td>
									<td>Unlimited subdomains</td>
								</tr>
								<tr>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
								</tr>
								<tr>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
								</tr>
								<tr>
									<td>MySql Support</td>
									<td>MySql Support</td>
									<td>MySql Support</td>
									<td>MySql Support</td>
								</tr>
								<tr>
									<td><span class="read_more">Sign up</span></td>
									<td><span class="read_more">Sign up</span></td>
									<td><span class="read_more">Sign up</span></td>
									<td><span class="read_more">Sign up</span></td>
								</tr>
								
							</tbody>
							
						</table>
					
					</div>
					
					<div class="su-table su-table-style-3">
					
						<table class="custom-table">
						
							<thead>
							
								<tr>
									<th>Basic Plan</th>
									<th>Standard Plan</th>
									<th>Featured Plan</th>
									<th>Delux Plan</th>
								</tr>
								
							</thead>
							
							<tbody>
							
								<tr>
									<td>1000Mb Monthly traffic</td>
									<td>5000Mb Monthly traffic</td>
									<td>1000Mb Monthly traffic</td>
									<td>50000Mb Monthly traffic</td>
								</tr>
								<tr>
									<td>10Gb Disk space</td>
									<td>50Gb Disk space</td>
									<td>100Gb Disk space</td>
									<td>150Gb Disk space</td>
								</tr>
								<tr>
									<td>5 Domains</td>
									<td>10 Domains</td>
									<td>25 Domains</td>
									<td>50 Domains</td>
								</tr>
								<tr>
									<td>5 Subdomains</td>
									<td>10 Subdomains</td>
									<td>35 Subdomains</td>
									<td>Unlimited subdomains</td>
								</tr>
								<tr>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
									<td>Unlimited email support</td>
								</tr>
								<tr>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
									<td>PHP 5 Support</td>
								</tr>
								<tr>
									<td>MySql Support</td>
									<td>MySql Support</td>
									<td>MySql Support</td>
									<td>MySql Support</td>
								</tr>
								<tr>
									<td><span class="read_more">Sign up</span></td>
									<td><span class="read_more">Sign up</span></td>
									<td><span class="read_more">Sign up</span></td>
									<td><span class="read_more">Sign up</span></td>
								</tr>
								
							</tbody>
							
						</table>
					
					</div>