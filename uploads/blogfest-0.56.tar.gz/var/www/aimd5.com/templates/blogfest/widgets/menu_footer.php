        <div class="footer_menu">

            <ul>
                <li><a href="/index" title="home">Home</a></li>
                <li><a href="/faq" title="features">Features</a></li>
                <li><a href="/portfolio" title="portfolio">Portfolio</a></li>
                <li><a href="/elements" title="styles">Styles</a></li>
                <li><a href="/category" title="blog">Blog</a></li>
                <li><a href="/contact" title="contact">Contact</a></li>
            </ul>

        </div>