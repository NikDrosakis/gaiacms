<ul id="accordion"> 
					<li> 
						<a href="#" class="item">Pellentesque vel sem id libero mollis fermentum quis at est?</a> 
						<ul> 
							<li>Nunc congue, metus quis posuere tempor, nunc eros porta nibh, dignissim suscipit magna felis vitae velit. Quisque facilisis, felis placerat dignissim elementum,
							nisi massa malesuada nulla, in rutrum metus mauris at libero. Aliquam adipiscing tincidunt erat a fringilla. Fusce consequat ornare diam eget fermentum. 
							Curabitur pellentesque scelerisque pulvinar. Nullam sit amet ipsum non diam eleifend rhoncus. Pellentesque vel sem id libero mollis fermentum quis at est. 
							Integer vel tempus libero. In id tempus quam. Morbi euismod faucibus turpis eget imperdiet. Ut pharetra diam eu ligula tincidunt quis blandit leo sagittis.
							Donec elit risus, consequat quis mattis ac, auctor nec massa. </li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum quis diam sapien?</a> 
						<ul> 
							<li>Aliquam eu tortor neque, quis vulputate nisi. Sed semper, nisl non vulputate varius, lectus metus 
							ultricies ante, sed scelerisque mi lorem et massa. Quisque fringilla risus nec libero consectetur at laoreet felis varius. Vivamus adipiscing sollicitudin lectus,
							a gravida magna rutrum vel. Phasellus at eros eget felis fringilla ultrices. Morbi pellentesque mattis leo in molestie. Nam interdum sollicitudin magna, 
							ut porttitor tortor venenatis non. </li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Mauris mollis justo in ipsum aliquet molestie vestibulum non neque magna?</a> 
						<ul> 
							<li>Urabitur vestibulum lectus sed augue sollicitudin non tempus lorem tempus. Vivamus vestibulum enim sit amet dolor rhoncus sodales. Aenean ut odio mauris. 
							Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor. In bibendum, nibh a gravida porta</li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Pellentesque vel sem id libero mollis fermentum quis at est?</a> 
						<ul> 
							<li>Nunc congue, metus quis posuere tempor, nunc eros porta nibh, dignissim suscipit magna felis vitae velit. Quisque facilisis, felis placerat dignissim elementum,
							nisi massa malesuada nulla, in rutrum metus mauris at libero. Aliquam adipiscing tincidunt erat a fringilla. Fusce consequat ornare diam eget fermentum. 
							Curabitur pellentesque scelerisque pulvinar. Nullam sit amet ipsum non diam eleifend rhoncus. Pellentesque vel sem id libero mollis fermentum quis at est. 
							Integer vel tempus libero. In id tempus quam. Morbi euismod faucibus turpis eget imperdiet. Ut pharetra diam eu ligula tincidunt quis blandit leo sagittis.
							Donec elit risus, consequat quis mattis ac, auctor nec massa. </li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Donec eros augue tristique in feugiat ut pellentesque eget metus?</a> 
						<ul> 
							<li>Aliquam eu tortor neque, quis vulputate nisi. Sed semper, nisl non vulputate varius, lectus metus 
							ultricies ante, sed scelerisque mi lorem et massa. Quisque fringilla risus nec libero consectetur at laoreet felis varius. Vivamus adipiscing sollicitudin lectus,
							a gravida magna rutrum vel. Phasellus at eros eget felis fringilla ultrices. Morbi pellentesque mattis leo in molestie. Nam interdum sollicitudin magna, 
							ut porttitor tortor venenatis non. </li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Quisque eleifend, augue ac gravida convallis felis massa congue ipsum?</a> 
						<ul> 
							<li>Urabitur vestibulum lectus sed augue sollicitudin non tempus lorem tempus. Vivamus vestibulum enim sit amet dolor rhoncus sodales. Aenean ut odio mauris. 
							Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor. In bibendum, nibh a gravida porta</li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Ut ut est libero rhoncus luctus justo muris convallis sodales consequat?</a> 
						<ul> 
							<li>Nunc congue, metus quis posuere tempor, nunc eros porta nibh, dignissim suscipit magna felis vitae velit. Quisque facilisis, felis placerat dignissim elementum,
							nisi massa malesuada nulla, in rutrum metus mauris at libero. Aliquam adipiscing tincidunt erat a fringilla. Fusce consequat ornare diam eget fermentum. 
							Curabitur pellentesque scelerisque pulvinar. Nullam sit amet ipsum non diam eleifend rhoncus. Pellentesque vel sem id libero mollis fermentum quis at est. 
							Integer vel tempus libero. In id tempus quam. Morbi euismod faucibus turpis eget imperdiet. Ut pharetra diam eu ligula tincidunt quis blandit leo sagittis.
							Donec elit risus, consequat quis mattis ac, auctor nec massa. </li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Nullam ac nulla quis turpis eleifend aliquet eget vestibulum mi integer eros esti dapibus dictum ?</a> 
						<ul> 
							<li>Aliquam eu tortor neque, quis vulputate nisi. Sed semper, nisl non vulputate varius, lectus metus 
							ultricies ante, sed scelerisque mi lorem et massa. Quisque fringilla risus nec libero consectetur at laoreet felis varius. Vivamus adipiscing sollicitudin lectus,
							a gravida magna rutrum vel. Phasellus at eros eget felis fringilla ultrices. Morbi pellentesque mattis leo in molestie. Nam interdum sollicitudin magna, 
							ut porttitor tortor venenatis non. </li> 
						</ul> 
					</li> 
					<li> 
						<a href="#" class="item">Mauris mollis justo in ipsum aliquet molestie vestibulum non neque magna?</a> 
						<ul> 
							<li>Urabitur vestibulum lectus sed augue sollicitudin non tempus lorem tempus. Vivamus vestibulum enim sit amet dolor rhoncus sodales. Aenean ut odio mauris. 
							Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor. In bibendum, nibh a gravida porta</li> 
						</ul> 
					</li> 
				</ul> 