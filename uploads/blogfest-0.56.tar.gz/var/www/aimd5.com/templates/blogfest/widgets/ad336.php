			<div class="ad_336">
			
				<div class="ad"><a href="#" title="" ><img src="/templates/blogfest/images/336x280.gif" alt="Lorem ipsum" /></a></div>
				<div class="ad_note"><a href="#" title="Advertise here" >Advertise here</a></div>
				
			</div>