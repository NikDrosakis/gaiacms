	<div class="social_login">
			
	<!--	<div class="social_login_twitter">
				
<a href="#" title="Sign in with Twitter">Sign in with Twitter</a>
				
		</div> -->
			
	<div class="social_login_facebook">

		<!--
   Below we include the Login Button social plugin. This button uses
   the JavaScript SDK to present a graphical Login button that triggers
   the FB.login() function when clicked.
 -->
		<fb:login-button scope="public_profile,email,user_friends,about,education" onlogin="checkLoginState();"></fb:login-button>

<!--<a href="#" title="Sign in with Facebook" onlogin="checkLoginState();">Sign in with Facebook</a>-->
				
	</div>
			
	<!--	<div class="social_login_google">
				
<a href="#" title="Sign in with Google">Sign in with Google+</a>
				
	</div> --->
			
	</div>
		