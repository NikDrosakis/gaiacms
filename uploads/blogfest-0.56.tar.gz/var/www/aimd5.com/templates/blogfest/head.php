<link rel="stylesheet" href="/templates/blogfest/css/base.css" />
<link rel="stylesheet" href="/templates/blogfest/css/layout.css" />
<link rel="stylesheet" href="/templates/blogfest/css/skeleton.css" />
<link rel="stylesheet" href="/templates/blogfest/css/flexslider.css" />
<link rel="stylesheet" href="/templates/blogfest/css/prettyPhoto.css" />

<!--[if  IE]>
<link rel="stylesheet" href="/templates/blogfest/css/ie.css">
<![endif]-->

<!--[if lt IE 9]>
<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
<![endif]-->

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->