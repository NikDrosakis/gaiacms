<div style="margin:15px">
<a class="twitter-timeline" href="https://twitter.com/venceremospress">Tweets by venceremospress</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
</div>

<div class="copyright">
 <?=$this->is('copyright')?>
 v.<?=$this->is('this_version')?>
</div>


</div> <!-- sidebar end -->

<a href="#" class="scrollup">Scroll</a>
<!-- ====Footer===== -->

<footer>
 <!--   <div id="footer">-->

<?php // $this->page()->module('menu_footer'); ?>

<?php // $this->page()->module('social_footer'); ?>

 <!--       </div> -->

</footer>

</div>
</div>

<!-- ====Scripts==== -->

<script src="/templates/blogfest/js/make_dropdown.js"></script>
<script src="/templates/blogfest/js/jquery.infieldlabel.min.js"></script>
<script defer src="/templates/blogfest/js/functions.js"></script>
<script defer src="/templates/blogfest/js/jquery.flexslider.js"></script>
<!--<script src="/templates/blogfest/twitter/jquery.tweet.js"></script>--->
<script src="/templates/blogfest/js/jquery.prettyPhoto.js"></script>

<script type="text/javascript">

    $(window).load(function() {

        $('.flexslider').flexslider({
            animationLoop: true,
            controlNav: false,
            animation: "slide",
        });

        // lightbox
        $("a[data-rel^='prettyPhoto']").prettyPhoto();

    });

</script>

</body>
</html>