<?php
//If the form is submitted
if(isset($_POST['submit'])) {

	//Check to make sure that the name field is not empty
	if(trim($_POST['author']) == '') {
		$hasError = true;
	} else {
		$name = trim($_POST['author']);
	}


	//Check to make sure sure that a valid email address is submitted
	if(trim($_POST['email']) == '')  {
		$hasError = true;
	} else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$", trim($_POST['email']))) {
		$hasError = true;
	} else {
		$email = trim($_POST['email']);
	}

	//Check to make sure comments were entered
	if(trim($_POST['message']) == '') {
		$hasError = true;
	} else {
		if(function_exists('stripslashes')) {
			$comments = stripslashes(trim($_POST['message']));
		} else {
			$comments = trim($_POST['message']);
		}
	}

	//If there is no error, send the email
	if(!isset($hasError)) {
		$emailTo = 'venceremospress@gmail.com'; //Put your own email address here
		$body = "Name: $name \nEmail: $email \nWebsite: $url \n\n Message:\n$comments";
		$headers = 'From: <'.$email.'>' . "\r\n" . 'Reply-To: ' . $email;
		$subject = '[Contact Form] - Email from '.trim(str_replace(array("\r", "\n"), ' ', $name));
		
		mail($emailTo, $subject, $body, $headers);
		$emailSent = true;
	}
}
?>

<!doctype html>
<head>

  <meta charset="utf-8">
  
	<!-- Website title
        ================================================== -->
		<title>Contact us</title>
	  
		<meta name="description" content="">
	<!-- Mobile Specific Metas
	    ================================================== -->
		
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		
	<!-- Stylesheets
        ================================================== -->
		
		<link rel="stylesheet" href="css/base.css" />
		<link rel="stylesheet" href="css/layout.css" />
		<link rel="stylesheet" href="css/skeleton.css" />
		<link rel="stylesheet" href="css/flexslider.css" />
		
		<!--[if  IE]>
		<link rel="stylesheet" href="css/ie.css">
		<![endif]-->
		
		<!--[if lt IE 9]>
			<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->

		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
		<script src="js/jquery-1.7.1.min.js"></script>
		<script src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.pack.js" type="text/javascript"></script>

		<script type="text/javascript">
		

			$(document).ready(function(){
				// validate contact form on keyup and submit
				var validator = $("#commentform").validate({
					rules: {
						author: {
							required: true,
							minlength: 2
						},
						email: {
							required: true,
							email: true
						},
						message: {
							required: true,
							minlength: 10
						}
					},
					messages: {
						author: {
							required: "Please enter your name",
							minlength: $.format("Your name needs to be at least {0} characters")
						},
						email: {
							required: "Please enter your email address",
							minlength: "Please enter a valid email"
						},
						message: {
							required: "You need to enter a message!",
							minlength: $.format("Enter at least {0} characters")
						}
					},
					// set this class to error-labels to indicate valid fields
					success: function(label) {
						label.addClass("checked");
					}
				});
			});
			
		</script>
	
</head>

<body>

	<div id="wrapper">
  
		<div id="main">
		
			<header><!-- HEADER start here 
			================================================== -->
			
			<div class="header">
			
				<div class="logo center"><a href="preview/index.html"><img src="images/logo_big.jpg" alt="logo" /><span>Blogfest Concept</span></a></div>
			
			</div>
			
			<div id="dd" class="menu wrapper-dropdown"><span class="responsive_label">Select a page</span>
				
				<ul id="menu-mobile" class="dropdown">
					<li><a href="preview/index.html" title="home page">Home</a>
						<ul>
							<li><a href="preview/index2.html" title="home 2">Home 2</a></li>
							<li><a href="preview/index3.html" title="home 3">Home 3</a></li>
							<li><a href="preview/index4.html" title="home 4">Home 4</a></li>
						</ul>
					</li>
					<li><a href="preview/faq.html" title="Features">Features</a>
						<ul>
							<li><a href="preview/faq.html" title="home">FAQ</a></li>
							<li><a href="preview/404.html" title="404 error">404 Error</a></li>
							<li><a href="preview/advertising.html" title="Advertising">Advertising</a></li>
						</ul>
					</li>
					<li><a href="preview/portfolio.html" title="portfolio">Portfolio</a>
						<ul>
							<li><a href="preview/portfolio.html" title="portfolio">With slider</a>
							<li><a href="preview/portfolio-2col.html" title="portfolio 2">2 Columns</a>
							<li><a href="preview/portfolio-3col.html" title="portfolio 3">3 Columns</a>
						</ul>
					</li>
					<li><a href="preview/elements.html" title="styles">Styles</a>
						<ul>
							<li><a href="preview/elements.html" title="elements">Elements</a></li>
							<li><a href="preview/headings.html" title="headings">Headings</a>
							<li><a href="preview/tables.html" title="pricing boxes">Pricing tables</a></li>
						</ul>
					</li>
					<li><a href="preview/post.html" title="single blog post">Bloging</a>
						<ul>
							<li><a href="preview/category.html" title="category template">Category</a></li>
							<li><a href="preview/post.html" title="single blog post">Single post</a></li>
							<li><a href="preview/results.html" title="search results">Search results</a>
						</ul>
					</li>
					<li><a href="contact.php" title="Contact">Contact</a></li>
				</ul>
				
			</div>
			
			</header><!-- HEADER end here
			================================================== -->
			
			<div class="ad-728">
			
				<div class="banner"><a href="#" title="advertisement"><img src="images/728x90.gif" alt="Advertisement" /></a></div>
				<div class="promo"></div>
			
			</div>
			
			<!-- POSTS LISTINGS start here 
			================================================== -->
			
			<div class="post_container">
				
				<div class="post">

					<!-- COMMENT FORM start here 
					================================================== -->
			
					<div id="respond">
					
						<h2>Contact Form</h2>
						
						<?php if(isset($hasError)) { //If errors are found ?>
							<p class="error-msg">Please check if you've filled all the fields with valid information and try again. Thank you.</p>
						<?php } ?>

						<?php if(isset($emailSent) && $emailSent == true) { //If email is sent ?>
							<p class="success">
								<strong>Email Successfully Sent!</strong></br>
								Thank you for using our contact form <strong><?php echo $name;?></strong>! Your email was successfully sent and we'll be in touch with you soon.
							</p>
						<?php } ?>

						<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="commentform">
						
							<div class="form_row">
							
								<div class="form_item">
								
									<label for="author">Name *</label>
									<input type="text" name="author" id="author" class="required" value="" size="22" />
									
								</div>
								
								<div class="form_item">
								
									<label for="email">E-mail *</label>
									<input type="text" name="email" id="email" class="required email" value="" size="22" />
									
								</div>
								
								<div class="form_item">
								
									<label for="url">Website</label>
									<input type="text" name="url" id="url" value="" size="22" tabindex="3" />
									
								</div>
							
							</div>
							
							<div class="form_row">
							
								<div class="form_item_comment">
								
									<label for="comment">Message *</label>
									<textarea name="message" id="comment" class="required" cols="58" rows="10"></textarea>
									
								</div>
							
							</div >
							
							<div class="form_row">
							
								<div class="submit_comment">
								
									<input name="submit" type="submit" class="button" id="submitButton" value="Send Message"/>
								
								</div>
							
							</div>
							
					
						</form>
					
					</div>
				
				</div>

			</div>
			
			
			<!-- POSTS LISTINGS end here 
			================================================== -->
			
			
			<!-- WIDGET CONTENT start here 
			================================================== -->
		
			<div class="content">
				
				<div class="block_latest_left">
				
					<div class="header_line">
					
						<h1>latest posts from posuere</h1>
					
					</div>
					
					<div class="block_latest_content">
									
						<p><a href="#" title="Lorem ipsum"><img src="images/345x140.gif" alt="Lorem ipsum" /></a></p>
						
					</div>
					
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Lorem ipsum dolor sim ament Crasis">Lorem ipsum dolor sim ament Crasis</a></h3>
							<p>Posted on Jun 30, 2012 in <a href="#" title="Design magazine">Design Magazine</a> |  <a href="#" title="Comments">17 comments</a> </p>
							
						</div>
					
					</div>
				
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Dolor sit amet, consectetur</a></h3>
							<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">5 comments</a> </p>
							
						</div>
					
					</div>
				
				
				</div>
				
				<div class="block_latest_right">
				
					<div class="header_line">
					
						<h1>latest posts from fermentum</h1>
					
					</div>
					
					<div class="block_latest_content">
									
						<p><a href="#" title="Lorem ipsum"><img src="images/345x140.gif" alt="Lorem ipsum" /></a></p>
						
					</div>
					
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Nunc congue metus quis posuere tempor">Nunc congue metus quis posuere tempor</a></h3>
							<p>Posted on May 28, 2012 in <a href="#" title="Design magazine">Sci-Fi</a> |  <a href="#" title="Comments">2 comments</a> </p>
							
						</div>
					
					</div>
				
					<div class="article_preview">
					
						<div class="article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
						
						<div class="article_preview_content">
						
							<h3 class="dotted"><a href="#" title="Aenean vitae ultricies sapien adipiscing elit">Aenean vitae ultricies sapien adipiscing elit</a></h3>
							<p>Posted on May 21, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">8 comments</a> </p>
							
						</div>
					
					</div>
				
				
				</div>
			
			</div>
			
			<!-- WIDGET CONTENT end here 
			================================================== -->
		
		</div>
		
		<!-- Sidebar
			================================================== -->
		
		<div id="sidebar">
		
			<div class="social_counter">
			
				<div class="social_counter_twitter">
				
					<a href="http://twitter.com/designsmix" title="Follow us on Twitter">Twitter</a>
					<span id="twitter"></span>
				
				</div>
			
				<div class="social_counter_facebook">
				
					<a href="#" title="Like us on Facebook">Facebook</a>
					<span id="facebook"></span>
				</div>
			
				<div class="social_counter_delicious">
				
					<a href="#" title="bookmark us">Delicious</a>
					<span id="delicious"></span>
				</div>
			
				<div class="social_and_subscribe">
				
					<div class="social_icons">
					
						<ul>
							<li><a href="#" title="" ><img src="images/icon_twitter_2.png" alt="Twitter" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_facebook_2.png" alt="Facebook" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_behance.png" alt="Behance" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_dribbble.png" alt="Dribbble" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_flickr.png" alt="Flickr" /></a></li>
							<li><a href="#" title="" ><img src="images/icon_rss_2.png" alt="RSS" /></a></li>
						</ul>
					
					</div>
					
					<div class="subscribe">
					
						<form action="#" method="get" accept-charset="utf-8">
							<fieldset>
							<p><label for="s">subscribe with your email</label>
							<input type="text" class="subscribebox" name="s" value="" id="s"/>
							<input type="submit" class="subscribebox_submit" value="" /></p>
							</fieldset>
						</form>
					
					</div>
				
				</div>
			
			</div>
			
			<div class="article_widget">
			
				<div class="article_widget_preview">
				
					<a href="#" title="" ><img src="images/200x125.gif" alt="lorem ipsum" /></a>
					
					<h1><a href="#" title="faucibus turpis eget i perdiet esci">faucibus turpis eget i perdiet esci</a></h1>
					
					<p>
						Sed sed arcu sed sem consequat ultricies vitae sit amet ipsum. Curabitur quis diam sapien...
					</p>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Aliquam bibendum consequat vene">Aliquam bibendum ed consequat vene</a></h3>
						<p class="meta"><a href="#">June 12, 2012</a></p>
						<p class="comments"><a href="#">38</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Sed et hendrerit aenon dolor">Sed et hendrerit ut aenon dolor...</a></h3>
						<p class="meta"><a href="#">June 08, 2012</a></p>
						<p class="comments"><a href="#">177</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Curabitur dictum magna mi">Curabitur eros et dictum magna mi</a></h3>
						<p class="meta"><a href="#">June 05, 2012</a></p>
						<p class="comments"><a href="#">15</a></p>
						
					</div>
				
				</div>
			
				<div class="article_widget_listing ">
					
					<div class="article_widget_listing_th"><a href="#" title=""><img src="images/53x53.gif" alt="Lorem ipsum" /></a></div>
					
					<div class="article_widget_listing_content">
						
						<h3><a href="#" title="Pellentesque vel sem id libero mollis">Pellentesque vel sem id libero mollis</a></h3>
						<p class="meta"><a href="#">June 01, 2012</a></p>
						<p class="comments"><a href="#">103</a></p>
						
					</div>
				
				</div>
			
			</div>
			
			<div class="tab_widget">
			
				<ul class="tabs"> 
					<li class="active" ><em title="tab1">Popular  posts</em></li>
					<li><em title="tab2">recent  posts</em></li>
					<li><em title="tab3">Comments</em></li>
				</ul>	

				<div class="tab_container"> 

					 <div id="tab1" class="tab_content"> 
				 
						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Curabitur dictum magna mi iaculis bibendum</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">5 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Donec eros augue, tristique in feugiat ut pellentes</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Curagitur</a> |  <a href="#" title="Comments">0 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Donec eros augue, tristique in feugiat ut pellentes</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Curagitur</a> |  <a href="#" title="Comments">0 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Nullam sit amet ipsum non diam eleifend rhoncus</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Inspirational</a> |  <a href="#" title="Comments">21 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Quisque fringilla risus nec libero consectetur</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">32 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Quisque fringilla risus nec libero consectetur</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">32 comments</a> </p>
								
							</div>
						
						</div>

					 </div><!-- #tab1 -->
					 
					 <div id="tab2" class="tab_content"> 

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Mauris mollis justo in ipsum aliquet molestie</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Blogfest</a> |  <a href="#" title="Comments">22 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">In bibendum, nibh a gravida porta sapien neque</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Curagitur</a> |  <a href="#" title="Comments">54 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Curabitur vestibulum lectus sed augue sollicit</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Inspirational</a> |  <a href="#" title="Comments">2 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Vivamus adipiscing sollicitudin lectus</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">125 comments</a> </p>
								
							</div>
						
						</div>

						<div class="tab_article_preview">
						
							<div class="tab_article_preview_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_article_preview_content">
							
								<h3 class="dotted"><a href="#" title="Dolor sit amet, consectetur">Aenean felis arcu, suscipit vitae pulvinar</a></h3>
								<p>Posted on Jun 24, 2012 in <a href="#" title="Blogfest">Lorem Ipsum</a> |  <a href="#" title="Comments">10 comments</a> </p>
								
							</div>
						
						</div>

					 </div><!-- #tab2 -->
					 
					 <div id="tab3" class="tab_content"> 

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">John Doe</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title="">Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Karl Voch</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title=""> Quisque fringilla risus nec libero consectetur at laoreet felis varius. Vivamus adipiscing sollicitudin lectus vitae sit amet ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Vivian Li</a></span> commented on <a href="#">Inspirational</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title="">Phasellus at eros eget felis fringilla ultrices. Morbi pellentesque mattis leo in molestie ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Francis Flaubert</a></span> commented on <a href="#">Blogfest</a> - Jun 24, 2012</p>
								<p class="italic"><a href="#" title="">Vivamus vestibulum enim sit amet dolor rhoncus sodales. Aenean ut odio mauris eget felis  ...</a></p>
								
							</div>
						
						</div>

						<div class="tab_last_comments">
						
							<div class="tab_last_comments_th"><a href="#" title=""><img src="images/50x50.gif" alt="Lorem ipsum" /></a></div>
							
							<div class="tab_last_comments_content">
							
								<p><span class="author"><a href="#" title="">Gotze Mallermung</a></span> commented on <a href="#">Curagitur</a> - <span class="meta">Jun 24, 2012</span></p>
								<p class="italic"><a href="#" title="">Maecenas vel volutpat lacus. Sed accumsan massa id arcu interdum quis blandit eros auctor ...</a></p>
								
							</div>
						
						</div>

					 </div><!-- #tab3 -->
					 
					 
				 </div> <!-- .tab_container --> 
				
			</div>
			
			<div class="copyright">Copyright &copy; 2012 - Blogfest, HTML template by <a href="http://demo.foldingtheme.com/" target="_blank">Folding Theme</a></div>
		
		</div> <!-- sidebar end --> 
		
		<a href="#" class="scrollup">Scroll</a>
		
		<!-- Footer
			================================================== -->
		
		<footer>
		
			<div id="footer">
			
				<div class="footer_menu">
				
					<ul>
						<li><a href="preview/index.html" title="home">Home</a></li>
						<li><a href="preview/faq.html" title="features">Features</a></li>
						<li><a href="preview/portfolio.html" title="portfolio">Portfolio</a></li>
						<li><a href="preview/elements.html" title="styles">Styles</a></li>
						<li><a href="preview/category.html" title="blog">Blog</a></li>
						<li><a href="contact.php" title="contact">Contact</a></li>
					</ul>
				
				</div>
				
				<div class="footer_social">
				
					<ul>
						<li><a href="#" title="" ><img src="images/icon_rss.png" alt="RSS" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_twitter.png" alt="Twitter" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_facebook.png" alt="Facebook" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_deviantart.png" alt="DevianART" /></a></li>
						<li><a href="#" title="" ><img src="images/icon_vimeo.png" alt="Vimeo" /></a></li>
					</ul>
				
				</div>
			
			</div>

		</footer>

	</div>
  
  
	<!-- Scripts
        ================================================== -->

	<script src="/templates/blogfest/js/make_dropdown.js"></script>
		<script defer src="/templates/blogfest/js/jquery.infieldlabel.min.js"></script>
		<script defer src="/templates/blogfest/js/functions.js"></script>
		<script defer src="/templates/blogfest/js/jquery.flexslider.js"></script>
		<script src="/templates/blogfest/twitter/jquery.tweet.js"></script>

 </body>
</html>