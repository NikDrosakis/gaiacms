	<!-- POSTS LISTINGS start here
			================================================== -->
			
<div class="post_container">
			
<?php $this->page()->module('post5'); ?>
				
</div>
			
			<!-- POSTS LISTINGS end here 
			================================================== -->
			
<?php $this->page()->module('ad728'); ?>
			
			<!-- WIDGET CONTENT start here 
			================================================== -->
		
<div class="content">
		
<?php $this->page()->module('block_latest_left'); ?>				
				
</div>
			
			<!-- WIDGET CONTENT end here 
			================================================== -->
		
		</div>
		
		<!-- Sidebar
			================================================== -->
		
		<div id="sidebar">
		
<div class="social_counter">
			
<?php $this->page()->module('social_follow'); ?>	

<div class="social_and_subscribe">
				
<?php $this->page()->module('social'); ?>
<?php $this->page()->module('subscribe'); ?>			
				
</div>
			
	</div>
				
<?php $this->page()->module('ad200'); ?>
			
<?php $this->page()->module('article_widget'); ?>
			
<?php $this->page()->module('tab_widget'); ?>
			
<?php $this->page()->module('ad336'); ?>