<div class="post_container">

<div class="post">
    <?=$this->page()->custom($this->GS['page']);?>
</div>

</div>

</div>
		
<!-- Sidebar================================================== -->
		
<div id="sidebar">

<div class="social_and_search">

<?php $this->page()->module('social'); ?>
<?php $this->page()->module('subscribe'); ?>			
<?php // $this->page()->module('search'); ?>				
       </div>
				
<?php $this->page()->module('article_widget'); ?>
			
<?php $this->page()->module('tab_widget'); ?>
			
<?php $this->page()->module('twitter_widget'); ?>
