<?php $this->page()->module('post_listings'); ?>
<?php //$this--->page()->module('wp_pagenavi'); ?>

<!-- WIDGET CONTENT start here
			================================================== -->
		
	<div class="content">
				
<?php // $this--->page()->module('block_latest_left'); ?>
		
<!-- WIDGET CONTENT end here ================================================== -->
		
		</div>
		
<!-- Sidebar================================================== -->
		
	<div id="sidebar">

		<div class="social_and_search">

			<?php $this->page()->module('social'); ?>
			<?php $this->page()->module('subscribe'); ?>
			<?php // $this--->page()->module('search'); ?>

		</div>
			
<?php $this->page()->module('article_widget'); ?>

<?php $this->page()->module('tab_widget'); ?>
			
<?php $this->page()->module('twitter_widget'); ?></div>