<?php $this->page()->module('tier'); ?>
			
<!--==== MAIN CONTENT ===== -->
		
<?php $this->page()->module('post'); ?>
			
<?php // $this->page()->module('ad728'); ?>	
		
</div>		

<!-- =======Sidebar======= -->
		
<div id="sidebar">
		
			
<div class="social_and_search">
			
<?php $this->page()->module('social'); ?>
<?php $this->page()->module('search'); ?>
			
</div>
				
<?php $this->page()->module('ad200'); ?>
			
<?php $this->page()->module('ad120'); ?>
			
<?php $this->page()->module('ad336'); ?>