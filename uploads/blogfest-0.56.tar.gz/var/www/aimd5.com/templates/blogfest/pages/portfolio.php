<?php $this->page()->module('flexslider_portfolio'); ?>			
			
<?php $this->page()->module('flexslider_portfolio'); ?>			
			
<?php $this->page()->module('wp_pagenavi'); ?>	
		
</div>
		
<!-- Sidebar================================================== -->
		
<div id="sidebar">
		
<div class="social_and_search">			
		
<?php $this->page()->module('social'); ?>				
<?php $this->page()->module('search'); ?>
			
</div>
			
<?php $this->page()->module('ad200'); ?>
			
<?php $this->page()->module('article_widget_portfolio'); ?>