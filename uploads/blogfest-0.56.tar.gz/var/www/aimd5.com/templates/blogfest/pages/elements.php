<!-- POSTS LISTINGS start here
			================================================== -->
			
<div class="post_container">
			
<?php $this->page()->module('post2'); ?>					
				
<?php $this->page()->module('alert_boxes'); ?>				
				
<?php $this->page()->module('post3'); ?>				
				
<?php $this->page()->module('columns'); ?>
				
<?php $this->page()->module('call_to_action_box'); ?>
</div>
			
<!-- POSTS LISTINGS end here 
			================================================== -->
			
			
<!-- WIDGET CONTENT start here 
			================================================== -->
		
		</div>
		
		<!-- Sidebar
			================================================== -->
		
<div id="sidebar">
		
<?php $this->page()->module('social_login'); ?>
			
<?php $this->page()->module('login'); ?>			
		
<?php $this->page()->module('register'); ?>			
<div class="pass_recover">
			
<p>Forgot your password? Click <a href="#">here</a></p>
				
</div>
			
<div class="social_and_search">
			
<?php $this->page()->module('social'); ?>				
<?php $this->page()->module('search'); ?>
			
</div>
				
<?php $this->page()->module('ad200'); ?>
			
<?php $this->page()->module('article_widget'); ?>
<?php $this->page()->module('tab_widget'); ?>			