<!-- POSTS LISTINGS start here
			================================================== -->
			
			<div class="content search_results">
				
<?php $this->page()->module('block_latest_left'); ?>
			
			</div>
				
<?php $this->page()->module('wp_pagenavi'); ?>
			
		</div>
		
		<!-- Sidebar
			================================================== -->
		
		<div id="sidebar">
		
			<div class="social_counter">
			
<?php $this->page()->module('social_follow'); ?>
			
<div class="social_and_subscribe">
				
<?php $this->page()->module('social'); ?>
<?php $this->page()->module('subscribe'); ?>
				
</div>
			
			</div>
				
<?php $this->page()->module('ad200'); ?>
			
<?php $this->page()->module('article_widget'); ?>

<?php $this->page()->module('tab_widget'); ?>
			
			